﻿
namespace IndividualAssignment
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblDBWelcome = new System.Windows.Forms.Label();
            this.lblServerName = new System.Windows.Forms.Label();
            this.lblDBPassword = new System.Windows.Forms.Label();
            this.lblDBUsername = new System.Windows.Forms.Label();
            this.txtServername = new System.Windows.Forms.TextBox();
            this.txtDBUsername = new System.Windows.Forms.TextBox();
            this.txtDBPassword = new System.Windows.Forms.TextBox();
            this.gboDBLogin = new System.Windows.Forms.GroupBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gboLandingScreen = new System.Windows.Forms.GroupBox();
            this.lblWelcomeDesc = new System.Windows.Forms.Label();
            this.lblWelcomeTitle = new System.Windows.Forms.Label();
            this.gboDBLogin.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.gboLandingScreen.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDBWelcome
            // 
            this.lblDBWelcome.AutoSize = true;
            this.lblDBWelcome.Location = new System.Drawing.Point(209, 57);
            this.lblDBWelcome.Name = "lblDBWelcome";
            this.lblDBWelcome.Size = new System.Drawing.Size(241, 50);
            this.lblDBWelcome.TabIndex = 0;
            this.lblDBWelcome.Text = "Welcome!\r\nPlease connect to a database";
            // 
            // lblServerName
            // 
            this.lblServerName.AutoSize = true;
            this.lblServerName.Location = new System.Drawing.Point(209, 127);
            this.lblServerName.Name = "lblServerName";
            this.lblServerName.Size = new System.Drawing.Size(113, 25);
            this.lblServerName.TabIndex = 1;
            this.lblServerName.Text = "Server Name";
            // 
            // lblDBPassword
            // 
            this.lblDBPassword.AutoSize = true;
            this.lblDBPassword.Location = new System.Drawing.Point(235, 248);
            this.lblDBPassword.Name = "lblDBPassword";
            this.lblDBPassword.Size = new System.Drawing.Size(87, 25);
            this.lblDBPassword.TabIndex = 2;
            this.lblDBPassword.Text = "Password";
            // 
            // lblDBUsername
            // 
            this.lblDBUsername.AutoSize = true;
            this.lblDBUsername.Location = new System.Drawing.Point(231, 185);
            this.lblDBUsername.Name = "lblDBUsername";
            this.lblDBUsername.Size = new System.Drawing.Size(91, 25);
            this.lblDBUsername.TabIndex = 3;
            this.lblDBUsername.Text = "Username";
            // 
            // txtServername
            // 
            this.txtServername.Location = new System.Drawing.Point(371, 127);
            this.txtServername.Name = "txtServername";
            this.txtServername.Size = new System.Drawing.Size(309, 31);
            this.txtServername.TabIndex = 4;
            // 
            // txtDBUsername
            // 
            this.txtDBUsername.Location = new System.Drawing.Point(371, 185);
            this.txtDBUsername.Name = "txtDBUsername";
            this.txtDBUsername.Size = new System.Drawing.Size(309, 31);
            this.txtDBUsername.TabIndex = 5;
            // 
            // txtDBPassword
            // 
            this.txtDBPassword.Location = new System.Drawing.Point(371, 242);
            this.txtDBPassword.Name = "txtDBPassword";
            this.txtDBPassword.Size = new System.Drawing.Size(309, 31);
            this.txtDBPassword.TabIndex = 6;
            // 
            // gboDBLogin
            // 
            this.gboDBLogin.Controls.Add(this.btnConnect);
            this.gboDBLogin.Controls.Add(this.lblDBWelcome);
            this.gboDBLogin.Controls.Add(this.txtDBPassword);
            this.gboDBLogin.Controls.Add(this.lblServerName);
            this.gboDBLogin.Controls.Add(this.txtDBUsername);
            this.gboDBLogin.Controls.Add(this.lblDBUsername);
            this.gboDBLogin.Controls.Add(this.txtServername);
            this.gboDBLogin.Controls.Add(this.lblDBPassword);
            this.gboDBLogin.Location = new System.Drawing.Point(40, 63);
            this.gboDBLogin.Name = "gboDBLogin";
            this.gboDBLogin.Size = new System.Drawing.Size(769, 440);
            this.gboDBLogin.TabIndex = 7;
            this.gboDBLogin.TabStop = false;
            this.gboDBLogin.Text = "Database Login";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(530, 298);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(150, 34);
            this.btnConnect.TabIndex = 7;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.addToolStripMenuItem,
            this.changeToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1011, 33);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(77, 29);
            this.homeToolStripMenuItem.Text = "Home";
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.homeToolStripMenuItem_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(80, 29);
            this.searchToolStripMenuItem.Text = "Search";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(62, 29);
            this.addToolStripMenuItem.Text = "Add";
            // 
            // changeToolStripMenuItem
            // 
            this.changeToolStripMenuItem.Name = "changeToolStripMenuItem";
            this.changeToolStripMenuItem.Size = new System.Drawing.Size(88, 29);
            this.changeToolStripMenuItem.Text = "Change";
            this.changeToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(55, 29);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // gboLandingScreen
            // 
            this.gboLandingScreen.Controls.Add(this.lblWelcomeDesc);
            this.gboLandingScreen.Controls.Add(this.lblWelcomeTitle);
            this.gboLandingScreen.Location = new System.Drawing.Point(892, 437);
            this.gboLandingScreen.Name = "gboLandingScreen";
            this.gboLandingScreen.Size = new System.Drawing.Size(107, 90);
            this.gboLandingScreen.TabIndex = 9;
            this.gboLandingScreen.TabStop = false;
            this.gboLandingScreen.Text = "Welcome!";
            // 
            // lblWelcomeDesc
            // 
            this.lblWelcomeDesc.AutoSize = true;
            this.lblWelcomeDesc.Location = new System.Drawing.Point(28, 116);
            this.lblWelcomeDesc.Name = "lblWelcomeDesc";
            this.lblWelcomeDesc.Size = new System.Drawing.Size(902, 300);
            this.lblWelcomeDesc.TabIndex = 1;
            this.lblWelcomeDesc.Text = resources.GetString("lblWelcomeDesc.Text");
            // 
            // lblWelcomeTitle
            // 
            this.lblWelcomeTitle.AutoSize = true;
            this.lblWelcomeTitle.Location = new System.Drawing.Point(284, 57);
            this.lblWelcomeTitle.Name = "lblWelcomeTitle";
            this.lblWelcomeTitle.Size = new System.Drawing.Size(349, 25);
            this.lblWelcomeTitle.TabIndex = 0;
            this.lblWelcomeTitle.Text = "Welcome to the Course Search Application";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 602);
            this.Controls.Add(this.gboLandingScreen);
            this.Controls.Add(this.gboDBLogin);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.gboDBLogin.ResumeLayout(false);
            this.gboDBLogin.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.gboLandingScreen.ResumeLayout(false);
            this.gboLandingScreen.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDBWelcome;
        private System.Windows.Forms.Label lblServerName;
        private System.Windows.Forms.Label lblDBPassword;
        private System.Windows.Forms.Label lblDBUsername;
        private System.Windows.Forms.TextBox txtServername;
        private System.Windows.Forms.TextBox txtDBUsername;
        private System.Windows.Forms.TextBox txtDBPassword;
        private System.Windows.Forms.GroupBox gboDBLogin;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.GroupBox gboLandingScreen;
        private System.Windows.Forms.Label lblWelcomeDesc;
        private System.Windows.Forms.Label lblWelcomeTitle;
    }
}

