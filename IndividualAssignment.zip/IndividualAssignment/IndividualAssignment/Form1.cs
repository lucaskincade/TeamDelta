﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace IndividualAssignment
{

    public partial class Form1 : Form
    {

        string dbServerName;
        string dbUsername;
        string dbPassword;

        SqlConnection connection;
        SqlCommand command;
        SqlDataReader datareader;
        string connectionString;
        public Form1()
        {
            InitializeComponent();
            menuStrip1.Enabled = false;
            menuStrip1.Visible = false;
            showLogin();

        }

        private void showLogin()
        {
            gboDBLogin.Dock = DockStyle.Fill;
            gboDBLogin.Visible = true;
            gboLandingScreen.Visible = false;
        }
        private void showHome()
        {
            gboLandingScreen.Dock = DockStyle.Fill;
            gboLandingScreen.Visible = true;
            gboDBLogin.Visible = false;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            dbServerName = txtServername.Text;
            dbUsername = txtDBUsername.Text;
            dbPassword = txtDBPassword.Text;

            try
            {
                connectionString = "Data Source=" + "'" + dbServerName + "'" + ";Initial Catalog=" + "'" + dbUsername + "'" + ";User ID=" + "'" + dbUsername + "'" + ";Password=" + "'" + dbPassword + "'" + ";";

                connection = new SqlConnection(connectionString);
                connection.Open();

                MessageBox.Show("Connected to database.");

                menuStrip1.Enabled = true;
                menuStrip1.Visible = true;
                showHome();
                
            }
            catch
            {
                MessageBox.Show("One or more items are incorrect. Please try again.");
                txtServername.Clear();
                txtDBUsername.Clear();
                txtDBPassword.Clear();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showHome();
        }
    }
}
