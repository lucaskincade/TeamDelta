﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TeamDelta
{
    public partial class Form1 : Form
    {

        //Sql Login string
        string connectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2174;User ID=PROJECTF2174;Password=HW30hev$";
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader datareader;

        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void showLogin()
        {
            gboLogin.Dock = DockStyle.Fill;
            gboLogin.Visible = true;
            gboCreateAccount.Visible = false;
        }

        private void showCreateAccount()
        {
            gboCreateAccount.Dock = DockStyle.Fill;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtCreatePassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Your passwords do not match. Please re-enter your passwords");
            }

            //ACCOUNT CREATION

            try
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "INSERT INTO Customer (FirstName, LastName) VALUES (@fname, @lname)";
                command = new SqlCommand(sql, connection);

                command.Parameters.AddWithValue("@fname", txtCreateFirstName.Text);
                command.Parameters.AddWithValue("@lname", txtCreateLastName.Text);


                command.ExecuteNonQuery();


                sql = "INSERT INTO Login (Username, Password) VALUES (@em, @pw)";
                command = new SqlCommand(sql, connection);

                command.Parameters.AddWithValue("@em", txtCreateEmail.Text);
                command.Parameters.AddWithValue("@pw", txtCreatePassword.Text);


                command.ExecuteNonQuery();

                MessageBox.Show("You have successfully created an account!");

                connection.Close();
                command.Dispose();
            }
            catch
            {
                MessageBox.Show("One or more items was entered incorrectly.");
            }


        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showLogin();
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            showCreateAccount();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            showLogin();
        }
    }
}
