﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TeamDelta
{
    public partial class Form1 : Form
    {

        //Sql Login string
        string connectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2174;User ID=PROJECTF2174;Password=HW30hev$";
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader datareader;

        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void showLogin()
        {
            gboLogin.Dock = DockStyle.Fill;
            gboLogin.Visible = true;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
        }

        private void showCreateAccount()
        {
            gboCreateAccount.Dock = DockStyle.Fill;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = true;
            gboSearch.Visible = false;
        }

        private void showSearch()
        {
            gboSearch.Dock = DockStyle.Fill;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtCreatePassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Your passwords do not match. Please re-enter your passwords");
            }

            //ACCOUNT CREATION

            try
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "INSERT INTO Customer (FirstName, LastName) VALUES (@fname, @lname)";
                command = new SqlCommand(sql, connection);

                command.Parameters.AddWithValue("@fname", txtCreateFirstName.Text);
                command.Parameters.AddWithValue("@lname", txtCreateLastName.Text);


                command.ExecuteNonQuery();


                sql = "INSERT INTO Login (Username, Password) VALUES (@em, @pw)";
                command = new SqlCommand(sql, connection);

                command.Parameters.AddWithValue("@em", txtCreateEmail.Text);
                command.Parameters.AddWithValue("@pw", txtCreatePassword.Text);


                command.ExecuteNonQuery();

                MessageBox.Show("You have successfully created an account!");

                connection.Close();
                command.Dispose();
            }
            catch
            {
                MessageBox.Show("One or more items was entered incorrectly.");
            }


        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showLogin();
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            showCreateAccount();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            showLogin();
            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Make FROM Vehicle";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboMake.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }

            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Model FROM Vehicle";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboModel.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Year FROM Vehicle Order By Year";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboYear.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                showSearch();
                SqlConnection Connection;
                SqlCommand Command;
                DataTable dt = new DataTable();
                Connection = new SqlConnection(connectionString);
                Connection.Open();
                String sql = "Select Make, Model, Year, City, Highway From Vehicle";
                Command = new SqlCommand(sql, Connection);
                SqlDataAdapter da = new SqlDataAdapter(Command);
                da.Fill(dt);
                dgvSearch.DataSource = dt;
                Connection.Close();
                Command.Dispose();
            }
            catch
            {
                MessageBox.Show("Failure");
            }
        }

        private void cboMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboMake.Text + "%' AND Model LIKE '" + cboModel.Text + "%' AND Year LIKE '" + cboYear.Text + "%'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvSearch.DataSource = ds.Tables[0];
        }

        private void cboModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open(); 
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboMake.Text + "%' AND Model LIKE '" + cboModel.Text + "%' AND Year LIKE '" + cboYear.Text + "%'"; ;
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvSearch.DataSource = ds.Tables[0];
        }

        private void cboYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboMake.Text + "%' AND Model LIKE '" + cboModel.Text + "%' AND Year LIKE '" + cboYear.Text + "%'"; ;
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvSearch.DataSource = ds.Tables[0];
        }
    }
}
