﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TeamDelta
{
    public partial class Form1 : Form
    {

        //Sql Login string
        string connectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2174;User ID=PROJECTF2174;Password=HW30hev$";
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader datareader;
        string loginID;

        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void showLogin()
        {
            gboLogin.Dock = DockStyle.Fill;
            gboLogin.Visible = true;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = false;
        }

        private void showCreateAccount()
        {
            gboCreateAccount.Dock = DockStyle.Fill;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = true;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = false;
        }

        private void showSearch()
        {
            gboSearch.Dock = DockStyle.Fill;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = true;
            gboAddVehicle.Visible = false;
        }

        private void showAddVehicle()
        {
            gboAddVehicle.Dock = DockStyle.Fill;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = true;
        }

        private void populateCbo()
        {
            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Make FROM Vehicle";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboMake.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }

            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Model FROM Vehicle";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboModel.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Year FROM Vehicle Order By Year";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboYear.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

          

            if (txtCreatePassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Your passwords do not match. Please re-enter your passwords");
            }

            //ACCOUNT CREATION

            try
            {
                connection = new SqlConnection(connectionString);
                connection.Open();

                string sql = "INSERT INTO Login (Username, Password) VALUES (@em, @pw)";
                command = new SqlCommand(sql, connection);

                command.Parameters.AddWithValue("@em", txtCreateEmail.Text);
                command.Parameters.AddWithValue("@pw", txtCreatePassword.Text);


                command.ExecuteNonQuery();


             

                sql = "INSERT INTO Customer (FirstName, LastName) VALUES (@fname, @lname)";
                command = new SqlCommand(sql, connection);


                command.Parameters.AddWithValue("@fname", txtCreateFirstName.Text);
                command.Parameters.AddWithValue("@lname", txtCreateLastName.Text);


                command.ExecuteNonQuery();


                sql = "Update Customer set Customer.LoginID = (SELECT Login.LoginID from Login where Username = '" + txtCreateEmail + "'And Password = '" + txtCreatePassword + "') Where Username = '" + txtCreateEmail + "'And Password = '" + txtCreatePassword + "' ";
                command = new SqlCommand(sql, connection);

                


                command.ExecuteNonQuery();

                MessageBox.Show("You have successfully created an account!");

                connection.Close();
                command.Dispose();
            }
            catch
            {
                MessageBox.Show("One or more items was entered incorrectly.");
            }


        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showLogin();
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            showCreateAccount();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            showLogin();
            populateCbo();
            
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                showSearch();
                SqlConnection Connection;
                SqlCommand Command;
                DataTable dt = new DataTable();
                Connection = new SqlConnection(connectionString);
                Connection.Open();
                String sql = "Select Make, Model, Year, City, Highway From Vehicle";
                Command = new SqlCommand(sql, Connection);
                SqlDataAdapter da = new SqlDataAdapter(Command);
                da.Fill(dt);
                dgvSearch.DataSource = dt;
                Connection.Close();
                Command.Dispose();
            }
            catch
            {
                MessageBox.Show("Failure");
            }
        }

        private void cboMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboMake.Text + "%' AND Model LIKE '" + cboModel.Text + "%' AND Year LIKE '" + cboYear.Text + "%'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvSearch.DataSource = ds.Tables[0];

            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Model FROM Vehicle Where Make = '" + cboMake.Text + "'";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                cboModel.Items.Clear();
                while (datareader.Read())
                {
                    cboModel.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void cboModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open(); 
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboMake.Text + "%' AND Model LIKE '" + cboModel.Text + "%' AND Year LIKE '" + cboYear.Text + "%'"; ;
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvSearch.DataSource = ds.Tables[0];

            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Year FROM Vehicle Where Make = '" + cboMake.Text + "' AND Model = '" + cboModel.Text + "'"; 
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                cboYear.Items.Clear();
                while (datareader.Read())
                {
                    cboYear.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void cboYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboMake.Text + "%' AND Model LIKE '" + cboModel.Text + "%' AND Year LIKE '" + cboYear.Text + "%'"; ;
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvSearch.DataSource = ds.Tables[0];
        }

        private void btnAddVehicle_Click(object sender, EventArgs e)
        {
            if (cboMake.SelectedIndex == -1 || cboModel.SelectedIndex == -1 || cboYear.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a vehicle");
            }
            else
            {
                showAddVehicle();
                txtAddMake.Text = cboMake.Text;
                txtAddModel.Text = cboModel.Text;
                txtAddYear.Text = cboYear.Text;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try //Inserts a vehicle into the customerVehicle table
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                int answer;
                string sql = "INSERT INTO CustomerVehicle (CVehicleMake, CVehicleModel, CVehicleYear, CVehicleOdometer, CVehicleMaxFill) VALUES (@CVehicleMake, @CVehicleModel, @CVehicleYear, @CVehicleOdometer, @CVheicleMaxFill)";
                command = new SqlCommand(sql, connection);

                command.Parameters.AddWithValue("@CVehicleMake", txtAddMake.Text);
                command.Parameters.AddWithValue("@CVehicleModel", txtAddModel.Text);
                command.Parameters.AddWithValue("@CVehicleYear", txtAddYear.Text);
                command.Parameters.AddWithValue("@CVehicleOdometer", txtAddOdo.Text);
                command.Parameters.AddWithValue("@CVheicleMaxFill", txtAddMaxGallons.Text);


                answer = command.ExecuteNonQuery();

                sql = "Update CustomerVehicle SET (C.CVehicleFuelType = V.VehicleFuelType, C.CVehicleDrive = V.VehicleDrive, C.CVehicleTrans = V.VehicleTrans, C.CVehicleCyl = V.VehicleCyl, C.CVehicleLit = V.VehicleLit) FROM C.CustomerVehicle INNER JOIN V.Vehicle ON V.VehicleID = C.VehicleID";
                command.ExecuteNonQuery();

                connection.Close();
                command.Dispose();

                MessageBox.Show("You have added " + answer + "vehicle");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            string sql = "SELECT Username, Password, LoginID FROM Login WHERE LoginID = (SELECT LoginID FROM Login WHERE Username = '" + txtUserEmail.Text + "' AND Password = '" + txtUserPass.Text + "')";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            //Checks to see if the information lines up with SQL
            if (datareader.HasRows)
            {
                while (datareader.Read())
                {

                    if (datareader[0].ToString() == txtUserEmail.Text && datareader[1].ToString() == txtUserPass.Text)
                    {
                        
                        loginID = datareader[2].ToString();
                        MessageBox.Show("Welcome!");
                        
                    }

                }
            }
            else
            {
                MessageBox.Show("Login information was incorrect. Please try again or return to the main menu.");
                txtUserEmail.Clear();
                txtUserPass.Clear();
            }

            datareader.Close();

            int tempLoginID;
            sql = "SELECT CustomerID From Customer WHERE LoginID = " + "'" + loginID + "'";
            tempLoginID = command.ExecuteNonQuery();
            loginID = tempLoginID.ToString();

            //MessageBox.Show(tempLoginID.ToString());


            connection.Close();
            command.Dispose();
            
        }
    }
}
