﻿
namespace TeamDelta
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gboLogin = new System.Windows.Forms.GroupBox();
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.txtUserPass = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUserEmail = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gboCreateAccount = new System.Windows.Forms.GroupBox();
            this.txtCreateLastName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCreateFirstName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtCreatePassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCreateEmail = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gboSearch = new System.Windows.Forms.GroupBox();
            this.btnAddVehicle = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.cboYear = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cboModel = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cboMake = new System.Windows.Forms.ComboBox();
            this.dgvSearch = new System.Windows.Forms.DataGridView();
            this.gboAddVehicle = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtAddMaxGallons = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAddOdo = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtAddYear = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtAddModel = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtAddMake = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnPasswordRecovery = new System.Windows.Forms.Button();
            this.gboPasswordRecovery = new System.Windows.Forms.GroupBox();
            this.lblPasswordRecoveryEmail = new System.Windows.Forms.Label();
            this.txtPasswordRecoveryEmail = new System.Windows.Forms.TextBox();
            this.btnRecoverPassword = new System.Windows.Forms.Button();
            this.profileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gboLogin.SuspendLayout();
            this.gboCreateAccount.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.gboSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearch)).BeginInit();
            this.gboAddVehicle.SuspendLayout();
            this.gboPasswordRecovery.SuspendLayout();
            this.SuspendLayout();
            // 
            // gboLogin
            // 
            this.gboLogin.Controls.Add(this.btnPasswordRecovery);
            this.gboLogin.Controls.Add(this.btnCreateAccount);
            this.gboLogin.Controls.Add(this.btnLogin);
            this.gboLogin.Controls.Add(this.txtUserPass);
            this.gboLogin.Controls.Add(this.label2);
            this.gboLogin.Controls.Add(this.txtUserEmail);
            this.gboLogin.Controls.Add(this.label1);
            this.gboLogin.Location = new System.Drawing.Point(717, 62);
            this.gboLogin.Name = "gboLogin";
            this.gboLogin.Size = new System.Drawing.Size(36, 88);
            this.gboLogin.TabIndex = 0;
            this.gboLogin.TabStop = false;
            this.gboLogin.Text = "Login";
            this.gboLogin.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.Location = new System.Drawing.Point(311, 235);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(142, 67);
            this.btnCreateAccount.TabIndex = 5;
            this.btnCreateAccount.Text = "Create Account";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.btnCreateAccount_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(44, 235);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(142, 67);
            this.btnLogin.TabIndex = 4;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // txtUserPass
            // 
            this.txtUserPass.Location = new System.Drawing.Point(97, 97);
            this.txtUserPass.Name = "txtUserPass";
            this.txtUserPass.Size = new System.Drawing.Size(289, 20);
            this.txtUserPass.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Password";
            // 
            // txtUserEmail
            // 
            this.txtUserEmail.Location = new System.Drawing.Point(97, 71);
            this.txtUserEmail.Name = "txtUserEmail";
            this.txtUserEmail.Size = new System.Drawing.Size(289, 20);
            this.txtUserEmail.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Email";
            // 
            // gboCreateAccount
            // 
            this.gboCreateAccount.Controls.Add(this.txtCreateLastName);
            this.gboCreateAccount.Controls.Add(this.label7);
            this.gboCreateAccount.Controls.Add(this.txtCreateFirstName);
            this.gboCreateAccount.Controls.Add(this.label6);
            this.gboCreateAccount.Controls.Add(this.txtConfirmPassword);
            this.gboCreateAccount.Controls.Add(this.label5);
            this.gboCreateAccount.Controls.Add(this.button1);
            this.gboCreateAccount.Controls.Add(this.txtCreatePassword);
            this.gboCreateAccount.Controls.Add(this.label3);
            this.gboCreateAccount.Controls.Add(this.txtCreateEmail);
            this.gboCreateAccount.Controls.Add(this.label4);
            this.gboCreateAccount.Location = new System.Drawing.Point(275, 44);
            this.gboCreateAccount.Name = "gboCreateAccount";
            this.gboCreateAccount.Size = new System.Drawing.Size(109, 27);
            this.gboCreateAccount.TabIndex = 6;
            this.gboCreateAccount.TabStop = false;
            this.gboCreateAccount.Text = "Create Account";
            // 
            // txtCreateLastName
            // 
            this.txtCreateLastName.Location = new System.Drawing.Point(426, 60);
            this.txtCreateLastName.Name = "txtCreateLastName";
            this.txtCreateLastName.Size = new System.Drawing.Size(136, 20);
            this.txtCreateLastName.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(304, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Last Name";
            // 
            // txtCreateFirstName
            // 
            this.txtCreateFirstName.Location = new System.Drawing.Point(139, 60);
            this.txtCreateFirstName.Name = "txtCreateFirstName";
            this.txtCreateFirstName.Size = new System.Drawing.Size(136, 20);
            this.txtCreateFirstName.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "First Name";
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Location = new System.Drawing.Point(139, 142);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Size = new System.Drawing.Size(423, 20);
            this.txtConfirmPassword.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Confirm Password";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(255, 202);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 67);
            this.button1.TabIndex = 5;
            this.button1.Text = "Create Account";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtCreatePassword
            // 
            this.txtCreatePassword.Location = new System.Drawing.Point(139, 116);
            this.txtCreatePassword.Name = "txtCreatePassword";
            this.txtCreatePassword.Size = new System.Drawing.Size(423, 20);
            this.txtCreatePassword.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // txtCreateEmail
            // 
            this.txtCreateEmail.Location = new System.Drawing.Point(139, 90);
            this.txtCreateEmail.Name = "txtCreateEmail";
            this.txtCreateEmail.Size = new System.Drawing.Size(423, 20);
            this.txtCreateEmail.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Email";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginToolStripMenuItem,
            this.profileToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(944, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.loginToolStripMenuItem.Text = "Login";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.searchToolStripMenuItem.Text = "Search";
            this.searchToolStripMenuItem.Click += new System.EventHandler(this.searchToolStripMenuItem_Click);
            // 
            // gboSearch
            // 
            this.gboSearch.Controls.Add(this.btnAddVehicle);
            this.gboSearch.Controls.Add(this.label10);
            this.gboSearch.Controls.Add(this.cboYear);
            this.gboSearch.Controls.Add(this.label9);
            this.gboSearch.Controls.Add(this.cboModel);
            this.gboSearch.Controls.Add(this.label8);
            this.gboSearch.Controls.Add(this.cboMake);
            this.gboSearch.Controls.Add(this.dgvSearch);
            this.gboSearch.Location = new System.Drawing.Point(820, 44);
            this.gboSearch.Name = "gboSearch";
            this.gboSearch.Size = new System.Drawing.Size(51, 17);
            this.gboSearch.TabIndex = 8;
            this.gboSearch.TabStop = false;
            this.gboSearch.Text = "Search";
            // 
            // btnAddVehicle
            // 
            this.btnAddVehicle.Location = new System.Drawing.Point(267, 387);
            this.btnAddVehicle.Name = "btnAddVehicle";
            this.btnAddVehicle.Size = new System.Drawing.Size(319, 52);
            this.btnAddVehicle.TabIndex = 7;
            this.btnAddVehicle.Text = "Add Vehicle";
            this.btnAddVehicle.UseVisualStyleBackColor = true;
            this.btnAddVehicle.Click += new System.EventHandler(this.btnAddVehicle_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(538, 71);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Year";
            // 
            // cboYear
            // 
            this.cboYear.FormattingEnabled = true;
            this.cboYear.Location = new System.Drawing.Point(607, 68);
            this.cboYear.Name = "cboYear";
            this.cboYear.Size = new System.Drawing.Size(121, 21);
            this.cboYear.TabIndex = 5;
            this.cboYear.SelectedIndexChanged += new System.EventHandler(this.cboYear_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(297, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Model";
            // 
            // cboModel
            // 
            this.cboModel.FormattingEnabled = true;
            this.cboModel.Location = new System.Drawing.Point(366, 65);
            this.cboModel.Name = "cboModel";
            this.cboModel.Size = new System.Drawing.Size(121, 21);
            this.cboModel.TabIndex = 3;
            this.cboModel.SelectedIndexChanged += new System.EventHandler(this.cboModel_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(67, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Make";
            // 
            // cboMake
            // 
            this.cboMake.FormattingEnabled = true;
            this.cboMake.Location = new System.Drawing.Point(136, 65);
            this.cboMake.Name = "cboMake";
            this.cboMake.Size = new System.Drawing.Size(121, 21);
            this.cboMake.TabIndex = 1;
            this.cboMake.SelectedIndexChanged += new System.EventHandler(this.cboMake_SelectedIndexChanged);
            // 
            // dgvSearch
            // 
            this.dgvSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSearch.Location = new System.Drawing.Point(136, 122);
            this.dgvSearch.Name = "dgvSearch";
            this.dgvSearch.Size = new System.Drawing.Size(571, 247);
            this.dgvSearch.TabIndex = 0;
            // 
            // gboAddVehicle
            // 
            this.gboAddVehicle.Controls.Add(this.btnAdd);
            this.gboAddVehicle.Controls.Add(this.txtAddMaxGallons);
            this.gboAddVehicle.Controls.Add(this.label15);
            this.gboAddVehicle.Controls.Add(this.txtAddOdo);
            this.gboAddVehicle.Controls.Add(this.label14);
            this.gboAddVehicle.Controls.Add(this.txtAddYear);
            this.gboAddVehicle.Controls.Add(this.label13);
            this.gboAddVehicle.Controls.Add(this.txtAddModel);
            this.gboAddVehicle.Controls.Add(this.label12);
            this.gboAddVehicle.Controls.Add(this.txtAddMake);
            this.gboAddVehicle.Controls.Add(this.label11);
            this.gboAddVehicle.Location = new System.Drawing.Point(786, 317);
            this.gboAddVehicle.Name = "gboAddVehicle";
            this.gboAddVehicle.Size = new System.Drawing.Size(10, 166);
            this.gboAddVehicle.TabIndex = 9;
            this.gboAddVehicle.TabStop = false;
            this.gboAddVehicle.Text = "Add Vehicle";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(261, 244);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(254, 40);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add Vehicle";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtAddMaxGallons
            // 
            this.txtAddMaxGallons.Location = new System.Drawing.Point(464, 136);
            this.txtAddMaxGallons.Name = "txtAddMaxGallons";
            this.txtAddMaxGallons.Size = new System.Drawing.Size(117, 20);
            this.txtAddMaxGallons.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(384, 139);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 13);
            this.label15.TabIndex = 8;
            this.label15.Text = "Max Gallons";
            // 
            // txtAddOdo
            // 
            this.txtAddOdo.Location = new System.Drawing.Point(185, 138);
            this.txtAddOdo.Name = "txtAddOdo";
            this.txtAddOdo.Size = new System.Drawing.Size(117, 20);
            this.txtAddOdo.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(77, 139);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "Current Odometer";
            // 
            // txtAddYear
            // 
            this.txtAddYear.Location = new System.Drawing.Point(553, 46);
            this.txtAddYear.Name = "txtAddYear";
            this.txtAddYear.Size = new System.Drawing.Size(117, 20);
            this.txtAddYear.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(486, 47);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "Year";
            // 
            // txtAddModel
            // 
            this.txtAddModel.Location = new System.Drawing.Point(312, 45);
            this.txtAddModel.Name = "txtAddModel";
            this.txtAddModel.Size = new System.Drawing.Size(117, 20);
            this.txtAddModel.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(245, 46);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 2;
            this.label12.Text = "Model";
            // 
            // txtAddMake
            // 
            this.txtAddMake.Location = new System.Drawing.Point(88, 44);
            this.txtAddMake.Name = "txtAddMake";
            this.txtAddMake.Size = new System.Drawing.Size(117, 20);
            this.txtAddMake.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(21, 45);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Make";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.logoutToolStripMenuItem.Text = "Logout";
            // 
            // btnPasswordRecovery
            // 
            this.btnPasswordRecovery.Location = new System.Drawing.Point(393, 93);
            this.btnPasswordRecovery.Name = "btnPasswordRecovery";
            this.btnPasswordRecovery.Size = new System.Drawing.Size(114, 24);
            this.btnPasswordRecovery.TabIndex = 6;
            this.btnPasswordRecovery.Text = "Forgot password?";
            this.btnPasswordRecovery.UseVisualStyleBackColor = true;
            this.btnPasswordRecovery.Click += new System.EventHandler(this.btnPasswordRecovery_Click);
            // 
            // gboPasswordRecovery
            // 
            this.gboPasswordRecovery.Controls.Add(this.btnRecoverPassword);
            this.gboPasswordRecovery.Controls.Add(this.txtPasswordRecoveryEmail);
            this.gboPasswordRecovery.Controls.Add(this.lblPasswordRecoveryEmail);
            this.gboPasswordRecovery.Location = new System.Drawing.Point(24, 104);
            this.gboPasswordRecovery.Name = "gboPasswordRecovery";
            this.gboPasswordRecovery.Size = new System.Drawing.Size(613, 309);
            this.gboPasswordRecovery.TabIndex = 10;
            this.gboPasswordRecovery.TabStop = false;
            this.gboPasswordRecovery.Text = "Password Recovery";
            // 
            // lblPasswordRecoveryEmail
            // 
            this.lblPasswordRecoveryEmail.AutoSize = true;
            this.lblPasswordRecoveryEmail.Location = new System.Drawing.Point(47, 57);
            this.lblPasswordRecoveryEmail.Name = "lblPasswordRecoveryEmail";
            this.lblPasswordRecoveryEmail.Size = new System.Drawing.Size(32, 13);
            this.lblPasswordRecoveryEmail.TabIndex = 0;
            this.lblPasswordRecoveryEmail.Text = "Email";
            // 
            // txtPasswordRecoveryEmail
            // 
            this.txtPasswordRecoveryEmail.Location = new System.Drawing.Point(85, 54);
            this.txtPasswordRecoveryEmail.Name = "txtPasswordRecoveryEmail";
            this.txtPasswordRecoveryEmail.Size = new System.Drawing.Size(274, 20);
            this.txtPasswordRecoveryEmail.TabIndex = 1;
            // 
            // btnRecoverPassword
            // 
            this.btnRecoverPassword.Location = new System.Drawing.Point(224, 80);
            this.btnRecoverPassword.Name = "btnRecoverPassword";
            this.btnRecoverPassword.Size = new System.Drawing.Size(135, 23);
            this.btnRecoverPassword.TabIndex = 2;
            this.btnRecoverPassword.Text = "Recover Password";
            this.btnRecoverPassword.UseVisualStyleBackColor = true;
            this.btnRecoverPassword.Click += new System.EventHandler(this.btnRecoverPassword_Click);
            // 
            // profileToolStripMenuItem
            // 
            this.profileToolStripMenuItem.Name = "profileToolStripMenuItem";
            this.profileToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.profileToolStripMenuItem.Text = "Profile";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 561);
            this.Controls.Add(this.gboPasswordRecovery);
            this.Controls.Add(this.gboAddVehicle);
            this.Controls.Add(this.gboSearch);
            this.Controls.Add(this.gboCreateAccount);
            this.Controls.Add(this.gboLogin);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gboLogin.ResumeLayout(false);
            this.gboLogin.PerformLayout();
            this.gboCreateAccount.ResumeLayout(false);
            this.gboCreateAccount.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.gboSearch.ResumeLayout(false);
            this.gboSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearch)).EndInit();
            this.gboAddVehicle.ResumeLayout(false);
            this.gboAddVehicle.PerformLayout();
            this.gboPasswordRecovery.ResumeLayout(false);
            this.gboPasswordRecovery.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gboLogin;
        private System.Windows.Forms.Button btnCreateAccount;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.TextBox txtUserPass;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUserEmail;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gboCreateAccount;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtCreatePassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCreateEmail;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.TextBox txtCreateLastName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCreateFirstName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.GroupBox gboSearch;
        private System.Windows.Forms.DataGridView dgvSearch;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cboYear;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cboModel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cboMake;
        private System.Windows.Forms.Button btnAddVehicle;
        private System.Windows.Forms.GroupBox gboAddVehicle;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtAddMaxGallons;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAddOdo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtAddYear;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtAddModel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtAddMake;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Button btnPasswordRecovery;
        private System.Windows.Forms.GroupBox gboPasswordRecovery;
        private System.Windows.Forms.Button btnRecoverPassword;
        private System.Windows.Forms.TextBox txtPasswordRecoveryEmail;
        private System.Windows.Forms.Label lblPasswordRecoveryEmail;
        private System.Windows.Forms.ToolStripMenuItem profileToolStripMenuItem;
    }
}

