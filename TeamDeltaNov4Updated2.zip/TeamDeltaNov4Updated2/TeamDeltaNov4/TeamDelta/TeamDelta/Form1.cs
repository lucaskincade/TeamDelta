﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;

namespace TeamDelta
{
    public partial class Form1 : Form
    {

        //Sql Login string
        string connectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2174;User ID=PROJECTF2174;Password=HW30hev$";
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader datareader;
        string loginID;

        public Form1()
        {
            InitializeComponent();
            searchToolStripMenuItem.Enabled = false;
            logoutToolStripMenuItem.Enabled = false;
            profileToolStripMenuItem.Enabled = false;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void showPasswordRecovery()
        {
            gboPasswordRecovery.Dock = DockStyle.Fill;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = false;
            gboLogin.Visible = false;
            gboPasswordRecovery.Visible = true;
            gboAddVehicleSearch.Visible = false;
            gboFuelTracking.Visible = false;
        }

        private void showLogin()
        {
            gboLogin.Dock = DockStyle.Fill;
            gboLogin.Visible = true;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = false;
            gboPasswordRecovery.Visible = false;
            gboCompareVehicles.Visible = false;
            gboChangePassword.Visible = false;
            gboCusomterProfile.Visible = false;
            gboAddVehicleSearch.Visible = false;
            gboFuelTracking.Visible = false;
        }

        private void showCreateAccount()
        {
            gboCreateAccount.Dock = DockStyle.Fill;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = true;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = false;
            gboAddVehicleSearch.Visible = false;
            gboFuelTracking.Visible = false;
        }

        private void showCompareVehciles()
        {
            gboCompareVehicles.Dock = DockStyle.Fill;
            gboCompareVehicles.Visible = true;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = false;
            gboAddVehicleSearch.Visible = false;
            gboFuelTracking.Visible = false;
        }

        private void showCustomerLanding()
        {
            gboCusomterProfile.Dock = DockStyle.Fill;
            gboCusomterProfile.Visible = true;
            gboCompareVehicles.Visible = false;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = false;
            gboChangePassword.Visible = false;
            gboAddVehicle.Visible = false;
            gboPasswordRecovery.Visible = false;
            gboChangePassword.Visible = false;
            gboAddVehicleSearch.Visible = false;
            gboFuelTracking.Visible = false;
            txtCurrentPassword.Clear();
            txtNewPassword.Clear();
            txtConfirmNewPassword.Clear();
        }

        private void showChangePassword()
        {
            gboChangePassword.Dock = DockStyle.Fill;
            gboChangePassword.Visible = true;
            gboCompareVehicles.Visible = false;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = false;
            gboCusomterProfile.Visible = false;
            gboAddVehicle.Visible = false;
            gboPasswordRecovery.Visible = false;
            gboAddVehicleSearch.Visible = false;
            gboFuelTracking.Visible = false;
        }

        private void showSearch()
        {
            gboSearch.Dock = DockStyle.Fill;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = true;
            gboAddVehicle.Visible = false;
            gboCusomterProfile.Visible = false;
            gboCompareVehicles.Visible = false;
            gboAddVehicleSearch.Visible = false;
            gboFuelTracking.Visible = false;
        }

        private void showAddVehicle()
        {
            gboAddVehicle.Dock = DockStyle.Fill;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = true;
            gboAddVehicleSearch.Visible = false;
            gboFuelTracking.Visible = false;
        }

        private void showAddVehicleSearch()
        {
            gboAddVehicleSearch.Dock = DockStyle.Fill;
            gboChangePassword.Visible = false;
            gboCompareVehicles.Visible = false;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = false;
            gboCusomterProfile.Visible = false;
            gboAddVehicle.Visible = false;
            gboPasswordRecovery.Visible = false;
            gboAddVehicleSearch.Visible = true;
            gboFuelTracking.Visible = false;
        }

        private void showFuelTracking()
        {
            gboFuelTracking.Dock = DockStyle.Fill;
            gboChangePassword.Visible = false;
            gboCompareVehicles.Visible = false;
            gboLogin.Visible = false;
            gboCreateAccount.Visible = false;
            gboSearch.Visible = false;
            gboAddVehicle.Visible = false;
            gboCusomterProfile.Visible = false;
            gboAddVehicle.Visible = false;
            gboPasswordRecovery.Visible = false;
            gboAddVehicleSearch.Visible = false;
            gboFuelTracking.Visible = true;
        }

        private void populateCbo()
        {
            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Make FROM Vehicle";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboMake.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }

            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Model FROM Vehicle";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboModel.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Year FROM Vehicle Order By Year";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboYear.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void populateAddVehicleCbo()
        {
            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Make FROM Vehicle";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboAddVehicleSearchMake.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }

            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Model FROM Vehicle";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboAddVehicleSearchModel.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Year FROM Vehicle Order By Year";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    cboAddVehicleSearchYear.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {

          

            if (txtCreatePassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Your passwords do not match. Please re-enter your passwords");
            }

            //ACCOUNT CREATION

            try
            {
                connection = new SqlConnection(connectionString);
                connection.Open();

                string sql = "INSERT INTO Login (Username, Password) VALUES (@em, @pw)";
                command = new SqlCommand(sql, connection);

                command.Parameters.AddWithValue("@em", txtCreateEmail.Text);
                command.Parameters.AddWithValue("@pw", txtCreatePassword.Text);


                command.ExecuteNonQuery();


             

                sql = "INSERT INTO Customer (FirstName, LastName) VALUES (@fname, @lname)";
                command = new SqlCommand(sql, connection);


                command.Parameters.AddWithValue("@fname", txtCreateFirstName.Text);
                command.Parameters.AddWithValue("@lname", txtCreateLastName.Text);


                command.ExecuteNonQuery();


                sql = "Update Customer set Customer.LoginID = (SELECT Login.LoginID from Login where Username = '" + txtCreateEmail + "'And Password = '" + txtCreatePassword + "') Where Username = '" + txtCreateEmail + "'And Password = '" + txtCreatePassword + "' ";
                command = new SqlCommand(sql, connection);

                


                command.ExecuteNonQuery();

                MessageBox.Show("You have successfully created an account!");

                connection.Close();
                command.Dispose();
            }
            catch
            {
                MessageBox.Show("One or more items was entered incorrectly.");
            }


        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showLogin();
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            showCreateAccount();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            showLogin();
            populateCbo();
            
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                showSearch();
                SqlConnection Connection;
                SqlCommand Command;
                DataTable dt = new DataTable();
                Connection = new SqlConnection(connectionString);
                Connection.Open();
                String sql = "Select Make, Model, Year, City, Highway From Vehicle";
                Command = new SqlCommand(sql, Connection);
                SqlDataAdapter da = new SqlDataAdapter(Command);
                da.Fill(dt);
                dgvSearch.DataSource = dt;
                Connection.Close();
                Command.Dispose();
            }
            catch
            {
                MessageBox.Show("Failure");
            }
        }

        private void cboMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboMake.Text + "%' AND Model LIKE '" + cboModel.Text + "%' AND Year LIKE '" + cboYear.Text + "%'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvSearch.DataSource = ds.Tables[0];

            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Model FROM Vehicle Where Make = '" + cboMake.Text + "'";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                cboModel.Items.Clear();
                while (datareader.Read())
                {
                    cboModel.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void cboModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open(); 
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboMake.Text + "%' AND Model LIKE '" + cboModel.Text + "%' AND Year LIKE '" + cboYear.Text + "%'"; ;
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvSearch.DataSource = ds.Tables[0];

            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Year FROM Vehicle Where Make = '" + cboMake.Text + "' AND Model = '" + cboModel.Text + "'"; 
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                cboYear.Items.Clear();
                while (datareader.Read())
                {
                    cboYear.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void cboYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboMake.Text + "%' AND Model LIKE '" + cboModel.Text + "%' AND Year LIKE '" + cboYear.Text + "%'"; ;
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvSearch.DataSource = ds.Tables[0];
        }

        private void btnAddVehicle_Click(object sender, EventArgs e)
        {
            /*if (cboMake.SelectedIndex == -1 || cboModel.SelectedIndex == -1 || cboYear.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a vehicle");
            }
            else
            {
                showAddVehicle();
                txtAddMake.Text = cboMake.Text;
                txtAddModel.Text = cboModel.Text;
                txtAddYear.Text = cboYear.Text;
            } */


            connection = new SqlConnection(connectionString);
            connection.Open();


            //This adds the vehicles(s) to the list box
            connection = new SqlConnection(connectionString);
            connection.Open();
            String sql = "SELECT Distinct Make, Model, Year FROM Vehicle WHERE Make = '" + cboMake.Text + "'" + "AND Model = '" + cboModel.Text + "'" + "AND Year = '" + cboYear.Text + "'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                listBoxCompareCart.Items.Add(string.Format("{0},{1},{2}", datareader[0].ToString(), datareader[1].ToString(), datareader[2].ToString()));
            }

            connection.Close();
            command.Dispose();
            datareader.Close();

            cboMake.Text = "";
            cboModel.Text = "";
            cboYear.Text = "";

            dgvSearch.Refresh();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try //Inserts a vehicle into the customerVehicle table
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command2;
                SqlCommand command3;
                int temp1 = 0;
                int temp2 = 0;
                int answer;
                string sql = "INSERT INTO CustomerVehicle (CVehicleMake, CVehicleModel, CVehicleYear, CVehicleOdometer, CVehicleMaxFill, CustomerID, VehicleID) VALUES (@CVehicleMake, @CVehicleModel, @CVehicleYear, @CVehicleOdometer, @CVheicleMaxFill, @CID, @VID)";
                string sql2 = "SELECT Distinct CustomerID from Customer Where LoginID = '" + loginID + "'";
                string sql3 = "SELECT Distinct VehicleID FROM Vehicle WHERE Make = '" + txtAddMake.Text + "'" + "AND Model = '" + txtAddModel.Text + "'" + "AND Year = '" + txtAddYear.Text + "'";
                command = new SqlCommand(sql, connection);
                command2 = new SqlCommand(sql2, connection);
                command3 = new SqlCommand(sql3, connection);

                using (SqlDataReader datareader2 = command2.ExecuteReader())
                {
                    while (datareader2.Read())
                    {
                        temp1 = Convert.ToInt32(datareader2[0]);
                    }
                }

                using (SqlDataReader datareader3 = command3.ExecuteReader())
                {
                    while (datareader3.Read())
                    {
                        temp2 = Convert.ToInt32(datareader3[0]);
                    }
                }

                command.Parameters.AddWithValue("@CVehicleMake", txtAddMake.Text);
                command.Parameters.AddWithValue("@CVehicleModel", txtAddModel.Text);
                command.Parameters.AddWithValue("@CVehicleYear", txtAddYear.Text);
                command.Parameters.AddWithValue("@CVehicleOdometer", txtAddOdo.Text);
                command.Parameters.AddWithValue("@CVheicleMaxFill", txtAddMaxGallons.Text);
                command.Parameters.AddWithValue("@CID", temp1);
                command.Parameters.AddWithValue("@VID", temp2);


                answer = command.ExecuteNonQuery();

                connection.Close();
                command.Dispose();

                MessageBox.Show("You have added " + answer + " vehicle");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            string sql = "SELECT Username, Password, LoginID FROM Login WHERE LoginID = (SELECT LoginID FROM Login WHERE Username = '" + txtUserEmail.Text + "' AND Password = '" + txtUserPass.Text + "')";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            //Checks to see if the information lines up with SQL
            if (datareader.HasRows)
            {
                while (datareader.Read())
                {

                    if (datareader[0].ToString() == txtUserEmail.Text && datareader[1].ToString() == txtUserPass.Text)
                    {
                        
                        loginID = datareader[2].ToString();
                        MessageBox.Show("Welcome!");
                        loginToolStripMenuItem.Enabled = false;
                        searchToolStripMenuItem.Enabled = true;
                        logoutToolStripMenuItem.Enabled = true;
                        profileToolStripMenuItem.Enabled = true;
                        showCustomerLanding();
                    }

                }
            }
            else
            {
                MessageBox.Show("Login information was incorrect. Please try again or return to the main menu.");
                txtUserEmail.Clear();
                txtUserPass.Clear();
            }

            datareader.Close();

            /*int tempLoginID;
            datareader = command.ExecuteReader();
            sql = "SELECT CustomerID From Customer WHERE LoginID = " + "'" + loginID + "'";
            command = new SqlCommand(sql, connection);
            tempLoginID = command.ExecuteNonQuery();
            loginID = tempLoginID.ToString();

            */

            //MessageBox.Show(loginID);


            connection.Close();
            command.Dispose();
            
        }

        private void btnPasswordRecovery_Click(object sender, EventArgs e)
        {
            showPasswordRecovery();
        }

        private void btnRecoverPassword_Click(object sender, EventArgs e)
        {
            //Password Recovery Code
            //Generates a random password and sends it to the user. They will input their email address into a text box and click the "recover password" button.

            Random rnd = new Random();
            string[] alphabetArray = new string[26] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
            int[] numArray = new int[10] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            string newPassword = "";
            for (int i = 0; i < 10; i++)
            {
                if (i % 2 == 0)
                {
                    newPassword += alphabetArray[rnd.Next(0, 26)];
                }
                else
                {
                    newPassword += numArray[rnd.Next(0, 10)];
                }
            }

            try
            {
                MailMessage message = new MailMessage();
                SmtpClient smtp = new SmtpClient();

                message.From = new MailAddress("fueltrackingapplication@gmail.com");
                message.To.Add(new MailAddress(txtUserEmail.Text));
                message.Subject = "Password Recovery";
                message.Body = "This is your recovery password. Please use it to login and change your password.\n" + "Recovery Password:" + newPassword;

                smtp.Port = 587;
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential("fueltrackingapplication@gmail.com", "fueltrack");
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(message);

                connection = new SqlConnection(connectionString);
                connection.Open();
                //These values will change depending on what they are called in SQL
                string sql = "UPDATE Account SET password = @pw  WHERE UserEmail = @em";
                command = new SqlCommand(sql, connection);

                command.Parameters.AddWithValue("@pw", newPassword);
                command.Parameters.AddWithValue("@em", txtUserEmail.Text);

                command.ExecuteNonQuery();

                MessageBox.Show("An email has been sent containing a recovery password. Please use this password to login and then change your password.");

                connection.Close();
                command.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine("err: " + ex.Message);
            }
        }

        private void listBoxCompareCart_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
            //Populates the datagrid with the information of the selected title
            connection = new SqlConnection(connectionString);
            connection.Open();

            //Error cathcing with the remove buttom on the list box
                try
                {
                    //If a user accidently clicks on the white space on the list box, it won't crash the application with an out of bounds error
                    if (listBoxCompareCart.SelectedItem != null)
                    {
                        var sql = "SELECT Model FROM Vehicle WHERE Model = '" + listBoxCompareCart.SelectedItem.ToString() + "'";
                        var da = new SqlDataAdapter(sql, connection);
                        var ds = new DataSet();
                        da.Fill(ds);
                        dgvSearch.DataSource = ds.Tables[0];

                        connection.Close();
                        command.Dispose();
                    }
                    else
                    {
                        //If the user clicks on the white space, it will automatically set the index to 0
                        listBoxCompareCart.SelectedIndex = 0;
                    }

                }

                catch
                {
                    listBoxCompareCart.SelectedIndex = -1;
                }
            */

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRemoveItem_Click(object sender, EventArgs e)
        {
            if (listBoxCompareCart.SelectedIndex > -1)
            {
                listBoxCompareCart.Items.RemoveAt(listBoxCompareCart.SelectedIndex);
                MessageBox.Show("Item was removed from your cart.");

            }
        }

        private void btnCompareVehicles_Click(object sender, EventArgs e)
        {
            if (listBoxCompareCart.Items.Count > 1)
            {
                showCompareVehciles();
                int size = listBoxCompareCart.Items.Count;
                dgvCompareVehicles.Columns.Add("", "");
                dgvCompareVehicles.Rows.Add("SCORE");
                dgvCompareVehicles.Rows.Add("Make");
                dgvCompareVehicles.Rows.Add("Model");
                dgvCompareVehicles.Rows.Add("Year");
                dgvCompareVehicles.Rows.Add("City MPG");
                dgvCompareVehicles.Rows.Add("Highway MPG");

                for (int i = 0; i < size; i++)
                {
                    string v = listBoxCompareCart.GetItemText(listBoxCompareCart.Items[i]);
                    dgvCompareVehicles.Columns.Add(v, v);
                    int index = 0;
                    string make = "";
                    string model = "";
                    string year = "";
                    string cityMPG = "";
                    string highwayMPG = "";
                    for (int j = 0; j < listBoxCompareCart.GetItemText(listBoxCompareCart.Items[i]).Length; j++)
                    {

                        if (listBoxCompareCart.GetItemText(listBoxCompareCart.Items[i]).Substring(j, 1) != ",")
                        {
                            make += listBoxCompareCart.GetItemText(listBoxCompareCart.Items[i]).Substring(j, 1);
                        }
                        else
                        {
                            index = j+1;
                            break;
                        }

                    }
                    for (int j = index; j < listBoxCompareCart.GetItemText(listBoxCompareCart.Items[i]).Length; j++)
                    {
                        if (listBoxCompareCart.GetItemText(listBoxCompareCart.Items[i]).Substring(j, 1) != ",")
                        {
                            model += listBoxCompareCart.GetItemText(listBoxCompareCart.Items[i]).Substring(j, 1);
                        }
                        else
                        {
                            index = j+1;
                            break;
                        }
                    }
                    for (int j = index; j < listBoxCompareCart.GetItemText(listBoxCompareCart.Items[i]).Length; j++)
                    {
                        if (listBoxCompareCart.GetItemText(listBoxCompareCart.Items[i]).Substring(j, 1) != ",")
                        {
                            year += listBoxCompareCart.GetItemText(listBoxCompareCart.Items[i]).Substring(j, 1);
                        }
                        else
                        {
                            index = j + 1;
                        }
                    }

                    dgvCompareVehicles.Rows[1].Cells[i + 1].Value = make;
                    dgvCompareVehicles.Rows[2].Cells[i + 1].Value = model;
                    dgvCompareVehicles.Rows[3].Cells[i + 1].Value = year;
                    connection = new SqlConnection(connectionString);
                    connection.Open();
                    string sql = "SELECT City FROM Vehicle WHERE Make = " + "'" + make + "'" + "AND Model= " + "'" + model + "'" + "AND Year= " + "'" + year + "'";
                    command = new SqlCommand(sql, connection);
                    cityMPG = command.ExecuteScalar().ToString();
                    dgvCompareVehicles.Rows[4].Cells[i + 1].Value = cityMPG;
                    sql = "SELECT Highway FROM Vehicle WHERE Make = " + "'" + make + "'" + "AND Model= " + "'" + model + "'" + "AND Year= " + "'" + year + "'";
                    command = new SqlCommand(sql, connection);
                    highwayMPG = command.ExecuteScalar().ToString();
                    dgvCompareVehicles.Rows[5].Cells[i + 1].Value = highwayMPG;
                    connection.Close();
                    command.Dispose();
                    if(Convert.ToDouble(cityMPG) * .55 + Convert.ToDouble(highwayMPG) * .45 < 20 )
                    {
                        dgvCompareVehicles.Rows[0].Cells[i + 1].Value = "Bad";
                    }
                    else if (Convert.ToDouble(cityMPG) * .55 + Convert.ToDouble(highwayMPG) * .45 > 20 && Convert.ToDouble(cityMPG) * .55 + Convert.ToDouble(highwayMPG) * .45 < 40)
                    {
                        dgvCompareVehicles.Rows[0].Cells[i + 1].Value = "Average";
                    }
                    else
                    {
                        dgvCompareVehicles.Rows[0].Cells[i + 1].Value = "Great";
                    }
                }
                
            }
            else
            {
                MessageBox.Show("Please select two or more vehicles to compare.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Change password
            showChangePassword();
        }

        private void btnViewCustomerVehicles_Click(object sender, EventArgs e)
        {

        }

        private void btnAddCustomerVehicle_Click(object sender, EventArgs e)
        {
            try
            {
                showAddVehicleSearch();
                populateAddVehicleCbo();
                SqlConnection Connection;
                SqlCommand Command;
                DataTable dt = new DataTable();
                Connection = new SqlConnection(connectionString);
                Connection.Open();
                String sql = "Select Make, Model, Year, City, Highway From Vehicle";
                Command = new SqlCommand(sql, Connection);
                SqlDataAdapter da = new SqlDataAdapter(Command);
                da.Fill(dt);
                dgvAddVehicleSearch.DataSource = dt;
                Connection.Close();
                Command.Dispose();
            }
            catch
            {
                MessageBox.Show("Failure");
            }
        }

        private void btnChangeUserPassword_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            string sql = "SELECT Password FROM Login WHERE LoginID = " + "'" + loginID + "'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while(datareader.Read())
            {
                if(txtCurrentPassword.Text == datareader[0].ToString())
                {
                    if(txtNewPassword.Text == txtConfirmNewPassword.Text)
                    {
                        sql = "UPDATE Login SET Password = @pw WHERE LoginID = " + "'" + loginID + "'";
                        command = new SqlCommand(sql, connection);
                        command.Parameters.AddWithValue("@pw", txtNewPassword.Text);
                        datareader.Close();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Password changed.");
                        showCustomerLanding();
                        txtCurrentPassword.Clear();
                        txtNewPassword.Clear();
                        txtConfirmNewPassword.Clear();
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Passwords do not match.");
                        txtCurrentPassword.Clear();
                        txtNewPassword.Clear();
                        txtConfirmNewPassword.Clear();
                    }
                }
                else
                {
                    MessageBox.Show("Current password is incorrect.");
                    txtCurrentPassword.Clear();
                    txtNewPassword.Clear();
                    txtConfirmNewPassword.Clear();
                }
            }
            datareader.Close();
            connection.Close();
            command.Dispose();
        }

        private void profileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showCustomerLanding();
        }

        private void btnReturnToSearch_Click(object sender, EventArgs e)
        {
            showSearch();
            dgvCompareVehicles.Rows.Clear();
            dgvCompareVehicles.Columns.Clear();
            dgvCompareVehicles.Refresh();
        }

        private void addVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                showAddVehicleSearch();
                populateAddVehicleCbo();
                SqlConnection Connection;
                SqlCommand Command;
                DataTable dt = new DataTable();
                Connection = new SqlConnection(connectionString);
                Connection.Open();
                String sql = "Select Make, Model, Year, City, Highway From Vehicle";
                Command = new SqlCommand(sql, Connection);
                SqlDataAdapter da = new SqlDataAdapter(Command);
                da.Fill(dt);
                dgvAddVehicleSearch.DataSource = dt;
                Connection.Close();
                Command.Dispose();
            }
            catch
            {
                MessageBox.Show("Failure");
            }
        }

        private void cboAddVehicleSearchMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboAddVehicleSearchMake.Text + "%' AND Model LIKE '" + cboAddVehicleSearchModel.Text + "%' AND Year LIKE '" + cboAddVehicleSearchYear.Text + "%'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvAddVehicleSearch.DataSource = ds.Tables[0];

            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Model FROM Vehicle Where Make = '" + cboAddVehicleSearchMake.Text + "'";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                cboAddVehicleSearchModel.Items.Clear();
                cboAddVehicleSearchYear.Items.Clear();
                while (datareader.Read())
                {
                    cboAddVehicleSearchModel.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void cboAddVehicleSearchModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboAddVehicleSearchMake.Text + "%' AND Model LIKE '" + cboAddVehicleSearchModel.Text + "%' AND Year LIKE '" + cboAddVehicleSearchYear.Text + "%'"; ;
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvAddVehicleSearch.DataSource = ds.Tables[0];

            try //Populates Make/Model/Year combo boxes
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = "SELECT Distinct Year FROM Vehicle Where Make = '" + cboAddVehicleSearchMake.Text + "' AND Model = '" + cboAddVehicleSearchModel.Text + "'";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                cboAddVehicleSearchYear.Items.Clear();
                while (datareader.Read())
                {
                    cboAddVehicleSearchYear.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                command.Dispose();
                datareader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void cboAddVehicleSearchYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            var sql2 = "SELECT Make, Model, Year, City, Highway From Vehicle WHERE Make LIKE '" + cboAddVehicleSearchMake.Text + "%' AND Model LIKE '" + cboAddVehicleSearchModel.Text + "%' AND Year LIKE '" + cboAddVehicleSearchYear.Text + "%'"; ;
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvAddVehicleSearch.DataSource = ds.Tables[0];
        }

        private void btnAddVehicleSearch_Click(object sender, EventArgs e)
        {
            if (cboAddVehicleSearchMake.SelectedIndex == -1 || cboAddVehicleSearchModel.SelectedIndex == -1 || cboAddVehicleSearchYear.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a vehicle");
            }
            else
            {
                showAddVehicle();
                txtAddMake.Text = cboAddVehicleSearchMake.Text;
                txtAddModel.Text = cboAddVehicleSearchModel.Text;
                txtAddYear.Text = cboAddVehicleSearchYear.Text;
            }
        }

        private void fuelTrackingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                showFuelTracking();
                SqlCommand command2;
                var temp1 = 0;
                DataTable dt = new DataTable();
                connection = new SqlConnection(connectionString);
                connection.Open();

                String sql = "Select CVehicleID, CVehicleMake, CVehicleModel, CVehicleYear, CVehicleOdometer, CVehicleMaxFill FROM CustomerVehicle WHERE CustomerID=@cid";
                string sql2 = "SELECT Distinct CustomerID from Customer Where LoginID = '" + loginID + "'";

                command = new SqlCommand(sql, connection);
                command2 = new SqlCommand(sql2, connection);

                using (SqlDataReader datareader2 = command2.ExecuteReader())
                {
                    while (datareader2.Read())
                    {
                        temp1 = Convert.ToInt32(datareader2[0]);
                    }
                }

                command.Parameters.AddWithValue("@cid", temp1);

                

                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
                dgvFuelTracking.DataSource = dt;
                connection.Close();
                command.Dispose();
            }
            catch
            {
                MessageBox.Show("Failure");
            }
        }

        private void btnFuelTracking_Click(object sender, EventArgs e)
        {
            try //Inserts a trip into the trip table
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command2;
                SqlCommand command3;
                SqlCommand command4;
                SqlCommand command5;
                SqlCommand command6;
                int VehicleID = 0;
                int PrevOdo = 0;
                float prevFill = 0;
                float currFill = 0;
                int currOdo = 0;
                float maxFill = 0;
                float gallonsFilled = 0;

                int answer;
                string sql = "INSERT INTO Trip (CVehicleID, VehicleID, PrevFillLine, PrevOdometer, CurrOdometer, FillDate, FillLine, Distance) VALUES (@cid, @vid, @prevfill, @prevodo, @currodo, @filldate, @fline, @dist)";
                string sql2 = "SELECT Distinct VehicleID from CustomerVehicle where CVehicleID=@cid";
                string sql3 = "Select Distinct CurrOdometer from Trip Where TripID = (Select Max(TripID) From Trip Where CvehicleID=@cid)";
                string sql4 = "Select Distinct FillLine from Trip Where TripID = (Select Max(TripID) From Trip Where CvehicleID=@cid)";
                string sql5 = "Select Distinct CVehicleOdometer from CustomerVehicle where CVehicleID=@cid";
                string sql6 = "Select Distinct CVehicleMaxFill from CustomerVehicle where CVehicleID=@cid";


                command = new SqlCommand(sql, connection);
                command2 = new SqlCommand(sql2, connection);
                command3 = new SqlCommand(sql3, connection);
                command4 = new SqlCommand(sql4, connection);
                command5 = new SqlCommand(sql5, connection);
                command6 = new SqlCommand(sql6, connection);


                command.Parameters.AddWithValue("@cid", dgvFuelTracking.CurrentRow.Cells[0].Value);
                command2.Parameters.AddWithValue("@cid", dgvFuelTracking.CurrentRow.Cells[0].Value);
                command3.Parameters.AddWithValue("@cid", dgvFuelTracking.CurrentRow.Cells[0].Value);
                command4.Parameters.AddWithValue("@cid", dgvFuelTracking.CurrentRow.Cells[0].Value);
                command5.Parameters.AddWithValue("@cid", dgvFuelTracking.CurrentRow.Cells[0].Value);
                command6.Parameters.AddWithValue("@cid", dgvFuelTracking.CurrentRow.Cells[0].Value);




                using (SqlDataReader datareader2 = command2.ExecuteReader())
                {
                    while (datareader2.Read())
                    {
                        VehicleID = Convert.ToInt32(datareader2[0]);
                    }
                }

                if (cboxFirstTrip.Checked == false)
                {
                    using (SqlDataReader datareader3 = command3.ExecuteReader())
                    {
                        while (datareader3.Read())
                        {
                            PrevOdo = Convert.ToInt32(datareader3[0]);
                        }
                    }
                }
                else if (cboxFirstTrip.Checked == true)
                {
                    using (SqlDataReader datareader5 = command5.ExecuteReader())
                    {
                        while (datareader5.Read())
                        {
                            PrevOdo = Convert.ToInt32(datareader5[0]);
                        }
                    }
                }

                if (cboxFirstTrip.Checked == false)
                {
                    using (SqlDataReader datareader4 = command4.ExecuteReader())
                    {
                        while (datareader4.Read())
                        {
                            prevFill = Convert.ToSingle(datareader4[0]);
                        }
                    }
                }
                else if (cboxFirstTrip.Checked == true)
                {
                    prevFill = 100;
                }

                using (SqlDataReader datareader6 = command6.ExecuteReader())
                {
                    while (datareader6.Read())
                    {
                        maxFill = Convert.ToSingle(datareader6[0]);
                    }
                }

                /* bool success = float.TryParse(txtFuelTrackingPercent.Text, out currFill);
                  if (success == false)
                  {
                      MessageBox.Show("Please enter a valid Fill Percent");
                  }

                  bool success2 = Int32.TryParse(txtFuelTrackingOdometer.Text, out currOdo);
                  if (success2 == false)
                  {
                      MessageBox.Show("Please enter a valid Current Odometer");
                  }
                */

                currFill = Convert.ToSingle(txtFuelTrackingPercent.Text);
                currOdo = Convert.ToInt32(txtFuelTrackingOdometer.Text);
                gallonsFilled = Convert.ToSingle(txtFuelTrackGallonsFilled.Text);

                int miles = currOdo - PrevOdo;
                float gallonsUsed = ((((prevFill / 100) * maxFill) - ((currFill / 100) * maxFill)) + gallonsFilled );
                float fuelEfficiency = Convert.ToSingle(miles) / gallonsUsed;
                try
                {
                    if (currOdo <= PrevOdo)
                    {
                        MessageBox.Show("Please enter a correct number for odometer");
                        txtFuelTrackGallonsFilled.Clear();
                        txtFuelTrackingOdometer.Clear();
                        txtFuelTrackingPercent.Clear();
                    }
                    else
                    {




                        command.Parameters.AddWithValue("@vid", VehicleID);
                        command.Parameters.AddWithValue("@prevfill", prevFill);
                        command.Parameters.AddWithValue("@prevodo", PrevOdo);
                        command.Parameters.AddWithValue("@currodo", currOdo);
                        command.Parameters.AddWithValue("@filldate", DateTime.Today);
                        command.Parameters.AddWithValue("@fline", currFill);
                        command.Parameters.AddWithValue("@dist", miles);



                        answer = command.ExecuteNonQuery();

                        connection.Close();
                        command.Dispose();

                        MessageBox.Show("You have added " + answer + " trip. Your fuel efficiency for this trip is " + fuelEfficiency + " MPG.");
                    }
                }
                catch
                {
                    MessageBox.Show("Please enter a correct number for odometer and fill line.");
                    txtFuelTrackGallonsFilled.Clear();
                    txtFuelTrackingOdometer.Clear();
                    txtFuelTrackingPercent.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Make sure to click the first trip checkbox if it is your first trip." + ex);
            }
        }
    }
}
