﻿
namespace TeamDelta
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.gboLogin = new System.Windows.Forms.GroupBox();
            this.picbFrontPage = new System.Windows.Forms.PictureBox();
            this.btnPasswordRecovery = new System.Windows.Forms.Button();
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.txtUserPass = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUserEmail = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gboSearch = new System.Windows.Forms.GroupBox();
            this.picbSearch = new System.Windows.Forms.PictureBox();
            this.btnRemoveItem = new System.Windows.Forms.Button();
            this.listBoxCompareCart = new System.Windows.Forms.ListBox();
            this.btnCompareVehicles = new System.Windows.Forms.Button();
            this.btnAddVehicle = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.cboYear = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cboModel = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cboMake = new System.Windows.Forms.ComboBox();
            this.dgvSearch = new System.Windows.Forms.DataGridView();
            this.gboCreateAccount = new System.Windows.Forms.GroupBox();
            this.txtCreateLastName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCreateFirstName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtCreatePassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCreateEmail = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.profileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gboAddVehicle = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtAddMaxGallons = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAddOdo = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtAddYear = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtAddModel = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtAddMake = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.gboPasswordRecovery = new System.Windows.Forms.GroupBox();
            this.btnRecoverPassword = new System.Windows.Forms.Button();
            this.txtPasswordRecoveryEmail = new System.Windows.Forms.TextBox();
            this.lblPasswordRecoveryEmail = new System.Windows.Forms.Label();
            this.gboCompareVehicles = new System.Windows.Forms.GroupBox();
            this.dgvCompareVehicles = new System.Windows.Forms.DataGridView();
            this.btnReturnToSearch = new System.Windows.Forms.Button();
            this.gboCusomterProfile = new System.Windows.Forms.GroupBox();
            this.btnCompare = new System.Windows.Forms.Button();
            this.btnViewTrips = new System.Windows.Forms.Button();
            this.btnChangePassword = new System.Windows.Forms.Button();
            this.btnViewCustomerVehicles = new System.Windows.Forms.Button();
            this.btnAddCustomerVehicle = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.gboChangePassword = new System.Windows.Forms.GroupBox();
            this.btnChangeUserPassword = new System.Windows.Forms.Button();
            this.txtConfirmNewPassword = new System.Windows.Forms.TextBox();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.txtCurrentPassword = new System.Windows.Forms.TextBox();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.lblNewPassword = new System.Windows.Forms.Label();
            this.lblCurrentPassword = new System.Windows.Forms.Label();
            this.gboAddVehicleSearch = new System.Windows.Forms.GroupBox();
            this.btnAddVehicleSearch = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.cboAddVehicleSearchYear = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cboAddVehicleSearchModel = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.cboAddVehicleSearchMake = new System.Windows.Forms.ComboBox();
            this.dgvAddVehicleSearch = new System.Windows.Forms.DataGridView();
            this.gboFuelTracking = new System.Windows.Forms.GroupBox();
            this.txtFuelTrackGallonsFilled = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.cboxFirstTrip = new System.Windows.Forms.CheckBox();
            this.dgvFuelTracking = new System.Windows.Forms.DataGridView();
            this.label24 = new System.Windows.Forms.Label();
            this.btnFuelTracking = new System.Windows.Forms.Button();
            this.txtFuelTrackingPercent = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtFuelTrackingOdometer = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.gboCustomerTrips = new System.Windows.Forms.GroupBox();
            this.graphCustomerTrip = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.listBoxCustomerVehicles = new System.Windows.Forms.ListBox();
            this.dgvCustomerTrips = new System.Windows.Forms.DataGridView();
            this.gboLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbFrontPage)).BeginInit();
            this.gboSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearch)).BeginInit();
            this.gboCreateAccount.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.gboAddVehicle.SuspendLayout();
            this.gboPasswordRecovery.SuspendLayout();
            this.gboCompareVehicles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCompareVehicles)).BeginInit();
            this.gboCusomterProfile.SuspendLayout();
            this.gboChangePassword.SuspendLayout();
            this.gboAddVehicleSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAddVehicleSearch)).BeginInit();
            this.gboFuelTracking.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFuelTracking)).BeginInit();
            this.gboCustomerTrips.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.graphCustomerTrip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerTrips)).BeginInit();
            this.SuspendLayout();
            // 
            // gboLogin
            // 
            this.gboLogin.Controls.Add(this.picbFrontPage);
            this.gboLogin.Controls.Add(this.btnPasswordRecovery);
            this.gboLogin.Controls.Add(this.btnCreateAccount);
            this.gboLogin.Controls.Add(this.btnLogin);
            this.gboLogin.Controls.Add(this.txtUserPass);
            this.gboLogin.Controls.Add(this.label2);
            this.gboLogin.Controls.Add(this.txtUserEmail);
            this.gboLogin.Controls.Add(this.label1);
            this.gboLogin.Location = new System.Drawing.Point(462, 242);
            this.gboLogin.Name = "gboLogin";
            this.gboLogin.Size = new System.Drawing.Size(318, 48);
            this.gboLogin.TabIndex = 0;
            this.gboLogin.TabStop = false;
            this.gboLogin.Text = "Login";
            this.gboLogin.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // picbFrontPage
            // 
            this.picbFrontPage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picbFrontPage.BackgroundImage")));
            this.picbFrontPage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picbFrontPage.Location = new System.Drawing.Point(509, 128);
            this.picbFrontPage.Name = "picbFrontPage";
            this.picbFrontPage.Size = new System.Drawing.Size(377, 158);
            this.picbFrontPage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picbFrontPage.TabIndex = 7;
            this.picbFrontPage.TabStop = false;
            // 
            // btnPasswordRecovery
            // 
            this.btnPasswordRecovery.Location = new System.Drawing.Point(393, 93);
            this.btnPasswordRecovery.Name = "btnPasswordRecovery";
            this.btnPasswordRecovery.Size = new System.Drawing.Size(114, 24);
            this.btnPasswordRecovery.TabIndex = 6;
            this.btnPasswordRecovery.Text = "Forgot password?";
            this.btnPasswordRecovery.UseVisualStyleBackColor = true;
            this.btnPasswordRecovery.Click += new System.EventHandler(this.btnPasswordRecovery_Click);
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.Location = new System.Drawing.Point(311, 235);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(142, 67);
            this.btnCreateAccount.TabIndex = 5;
            this.btnCreateAccount.Text = "Create Account";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.btnCreateAccount_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(44, 235);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(142, 67);
            this.btnLogin.TabIndex = 4;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // txtUserPass
            // 
            this.txtUserPass.Location = new System.Drawing.Point(97, 97);
            this.txtUserPass.Name = "txtUserPass";
            this.txtUserPass.PasswordChar = '*';
            this.txtUserPass.Size = new System.Drawing.Size(289, 20);
            this.txtUserPass.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Password";
            // 
            // txtUserEmail
            // 
            this.txtUserEmail.Location = new System.Drawing.Point(97, 71);
            this.txtUserEmail.Name = "txtUserEmail";
            this.txtUserEmail.Size = new System.Drawing.Size(289, 20);
            this.txtUserEmail.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Email";
            // 
            // gboSearch
            // 
            this.gboSearch.Controls.Add(this.picbSearch);
            this.gboSearch.Controls.Add(this.btnRemoveItem);
            this.gboSearch.Controls.Add(this.listBoxCompareCart);
            this.gboSearch.Controls.Add(this.btnCompareVehicles);
            this.gboSearch.Controls.Add(this.btnAddVehicle);
            this.gboSearch.Controls.Add(this.label10);
            this.gboSearch.Controls.Add(this.cboYear);
            this.gboSearch.Controls.Add(this.label9);
            this.gboSearch.Controls.Add(this.cboModel);
            this.gboSearch.Controls.Add(this.label8);
            this.gboSearch.Controls.Add(this.cboMake);
            this.gboSearch.Controls.Add(this.dgvSearch);
            this.gboSearch.Location = new System.Drawing.Point(919, 391);
            this.gboSearch.Name = "gboSearch";
            this.gboSearch.Size = new System.Drawing.Size(198, 43);
            this.gboSearch.TabIndex = 8;
            this.gboSearch.TabStop = false;
            this.gboSearch.Text = "Search";
            // 
            // picbSearch
            // 
            this.picbSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picbSearch.BackgroundImage")));
            this.picbSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picbSearch.Location = new System.Drawing.Point(15, 175);
            this.picbSearch.Name = "picbSearch";
            this.picbSearch.Size = new System.Drawing.Size(105, 117);
            this.picbSearch.TabIndex = 11;
            this.picbSearch.TabStop = false;
            this.picbSearch.Click += new System.EventHandler(this.picbSearch_Click);
            // 
            // btnRemoveItem
            // 
            this.btnRemoveItem.Location = new System.Drawing.Point(729, 366);
            this.btnRemoveItem.Name = "btnRemoveItem";
            this.btnRemoveItem.Size = new System.Drawing.Size(95, 22);
            this.btnRemoveItem.TabIndex = 10;
            this.btnRemoveItem.Text = "Remove";
            this.btnRemoveItem.UseVisualStyleBackColor = true;
            this.btnRemoveItem.Click += new System.EventHandler(this.btnRemoveItem_Click);
            // 
            // listBoxCompareCart
            // 
            this.listBoxCompareCart.FormattingEnabled = true;
            this.listBoxCompareCart.Location = new System.Drawing.Point(729, 122);
            this.listBoxCompareCart.Name = "listBoxCompareCart";
            this.listBoxCompareCart.Size = new System.Drawing.Size(120, 238);
            this.listBoxCompareCart.TabIndex = 9;
            this.listBoxCompareCart.SelectedIndexChanged += new System.EventHandler(this.listBoxCompareCart_SelectedIndexChanged);
            // 
            // btnCompareVehicles
            // 
            this.btnCompareVehicles.Location = new System.Drawing.Point(462, 387);
            this.btnCompareVehicles.Name = "btnCompareVehicles";
            this.btnCompareVehicles.Size = new System.Drawing.Size(105, 52);
            this.btnCompareVehicles.TabIndex = 8;
            this.btnCompareVehicles.Text = "Compare";
            this.btnCompareVehicles.UseVisualStyleBackColor = true;
            this.btnCompareVehicles.Click += new System.EventHandler(this.btnCompareVehicles_Click);
            // 
            // btnAddVehicle
            // 
            this.btnAddVehicle.Location = new System.Drawing.Point(267, 387);
            this.btnAddVehicle.Name = "btnAddVehicle";
            this.btnAddVehicle.Size = new System.Drawing.Size(105, 52);
            this.btnAddVehicle.TabIndex = 7;
            this.btnAddVehicle.Text = "Add Vehicle";
            this.btnAddVehicle.UseVisualStyleBackColor = true;
            this.btnAddVehicle.Click += new System.EventHandler(this.btnAddVehicle_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(538, 71);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Year";
            // 
            // cboYear
            // 
            this.cboYear.FormattingEnabled = true;
            this.cboYear.Location = new System.Drawing.Point(607, 68);
            this.cboYear.Name = "cboYear";
            this.cboYear.Size = new System.Drawing.Size(121, 21);
            this.cboYear.TabIndex = 5;
            this.cboYear.SelectedIndexChanged += new System.EventHandler(this.cboYear_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(297, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Model";
            // 
            // cboModel
            // 
            this.cboModel.FormattingEnabled = true;
            this.cboModel.Location = new System.Drawing.Point(366, 65);
            this.cboModel.Name = "cboModel";
            this.cboModel.Size = new System.Drawing.Size(121, 21);
            this.cboModel.TabIndex = 3;
            this.cboModel.SelectedIndexChanged += new System.EventHandler(this.cboModel_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(67, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Make";
            // 
            // cboMake
            // 
            this.cboMake.FormattingEnabled = true;
            this.cboMake.Location = new System.Drawing.Point(136, 65);
            this.cboMake.Name = "cboMake";
            this.cboMake.Size = new System.Drawing.Size(121, 21);
            this.cboMake.TabIndex = 1;
            this.cboMake.SelectedIndexChanged += new System.EventHandler(this.cboMake_SelectedIndexChanged);
            // 
            // dgvSearch
            // 
            this.dgvSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSearch.Location = new System.Drawing.Point(136, 122);
            this.dgvSearch.Name = "dgvSearch";
            this.dgvSearch.RowHeadersWidth = 62;
            this.dgvSearch.Size = new System.Drawing.Size(571, 247);
            this.dgvSearch.TabIndex = 0;
            // 
            // gboCreateAccount
            // 
            this.gboCreateAccount.Controls.Add(this.txtCreateLastName);
            this.gboCreateAccount.Controls.Add(this.label7);
            this.gboCreateAccount.Controls.Add(this.txtCreateFirstName);
            this.gboCreateAccount.Controls.Add(this.label6);
            this.gboCreateAccount.Controls.Add(this.txtConfirmPassword);
            this.gboCreateAccount.Controls.Add(this.label5);
            this.gboCreateAccount.Controls.Add(this.button1);
            this.gboCreateAccount.Controls.Add(this.txtCreatePassword);
            this.gboCreateAccount.Controls.Add(this.label3);
            this.gboCreateAccount.Controls.Add(this.txtCreateEmail);
            this.gboCreateAccount.Controls.Add(this.label4);
            this.gboCreateAccount.Location = new System.Drawing.Point(561, 143);
            this.gboCreateAccount.Name = "gboCreateAccount";
            this.gboCreateAccount.Size = new System.Drawing.Size(73, 45);
            this.gboCreateAccount.TabIndex = 6;
            this.gboCreateAccount.TabStop = false;
            this.gboCreateAccount.Text = "Create Account";
            // 
            // txtCreateLastName
            // 
            this.txtCreateLastName.Location = new System.Drawing.Point(426, 60);
            this.txtCreateLastName.Name = "txtCreateLastName";
            this.txtCreateLastName.Size = new System.Drawing.Size(136, 20);
            this.txtCreateLastName.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(304, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Last Name";
            // 
            // txtCreateFirstName
            // 
            this.txtCreateFirstName.Location = new System.Drawing.Point(139, 60);
            this.txtCreateFirstName.Name = "txtCreateFirstName";
            this.txtCreateFirstName.Size = new System.Drawing.Size(136, 20);
            this.txtCreateFirstName.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "First Name";
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Location = new System.Drawing.Point(139, 142);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.PasswordChar = '*';
            this.txtConfirmPassword.Size = new System.Drawing.Size(423, 20);
            this.txtConfirmPassword.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Confirm Password";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(255, 202);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 67);
            this.button1.TabIndex = 5;
            this.button1.Text = "Create Account";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtCreatePassword
            // 
            this.txtCreatePassword.Location = new System.Drawing.Point(139, 116);
            this.txtCreatePassword.Name = "txtCreatePassword";
            this.txtCreatePassword.PasswordChar = '*';
            this.txtCreatePassword.Size = new System.Drawing.Size(423, 20);
            this.txtCreatePassword.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // txtCreateEmail
            // 
            this.txtCreateEmail.Location = new System.Drawing.Point(139, 90);
            this.txtCreateEmail.Name = "txtCreateEmail";
            this.txtCreateEmail.Size = new System.Drawing.Size(423, 20);
            this.txtCreateEmail.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Email";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginToolStripMenuItem,
            this.profileToolStripMenuItem,
            this.logoutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(944, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(49, 22);
            this.loginToolStripMenuItem.Text = "Login";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // profileToolStripMenuItem
            // 
            this.profileToolStripMenuItem.Name = "profileToolStripMenuItem";
            this.profileToolStripMenuItem.Size = new System.Drawing.Size(53, 22);
            this.profileToolStripMenuItem.Text = "Profile";
            this.profileToolStripMenuItem.Click += new System.EventHandler(this.profileToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(57, 22);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // gboAddVehicle
            // 
            this.gboAddVehicle.Controls.Add(this.btnAdd);
            this.gboAddVehicle.Controls.Add(this.txtAddMaxGallons);
            this.gboAddVehicle.Controls.Add(this.label15);
            this.gboAddVehicle.Controls.Add(this.txtAddOdo);
            this.gboAddVehicle.Controls.Add(this.label14);
            this.gboAddVehicle.Controls.Add(this.txtAddYear);
            this.gboAddVehicle.Controls.Add(this.label13);
            this.gboAddVehicle.Controls.Add(this.txtAddModel);
            this.gboAddVehicle.Controls.Add(this.label12);
            this.gboAddVehicle.Controls.Add(this.txtAddMake);
            this.gboAddVehicle.Controls.Add(this.label11);
            this.gboAddVehicle.Location = new System.Drawing.Point(757, 125);
            this.gboAddVehicle.Name = "gboAddVehicle";
            this.gboAddVehicle.Size = new System.Drawing.Size(83, 24);
            this.gboAddVehicle.TabIndex = 9;
            this.gboAddVehicle.TabStop = false;
            this.gboAddVehicle.Text = "Add Vehicle";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(261, 244);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(254, 40);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add Vehicle";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtAddMaxGallons
            // 
            this.txtAddMaxGallons.Location = new System.Drawing.Point(464, 136);
            this.txtAddMaxGallons.Name = "txtAddMaxGallons";
            this.txtAddMaxGallons.Size = new System.Drawing.Size(117, 20);
            this.txtAddMaxGallons.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(384, 139);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 13);
            this.label15.TabIndex = 8;
            this.label15.Text = "Max Gallons";
            // 
            // txtAddOdo
            // 
            this.txtAddOdo.Location = new System.Drawing.Point(185, 138);
            this.txtAddOdo.Name = "txtAddOdo";
            this.txtAddOdo.Size = new System.Drawing.Size(117, 20);
            this.txtAddOdo.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(77, 139);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "Current Odometer";
            // 
            // txtAddYear
            // 
            this.txtAddYear.Location = new System.Drawing.Point(553, 46);
            this.txtAddYear.Name = "txtAddYear";
            this.txtAddYear.Size = new System.Drawing.Size(117, 20);
            this.txtAddYear.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(486, 47);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "Year";
            // 
            // txtAddModel
            // 
            this.txtAddModel.Location = new System.Drawing.Point(312, 45);
            this.txtAddModel.Name = "txtAddModel";
            this.txtAddModel.Size = new System.Drawing.Size(117, 20);
            this.txtAddModel.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(245, 46);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 2;
            this.label12.Text = "Model";
            // 
            // txtAddMake
            // 
            this.txtAddMake.Location = new System.Drawing.Point(88, 44);
            this.txtAddMake.Name = "txtAddMake";
            this.txtAddMake.Size = new System.Drawing.Size(117, 20);
            this.txtAddMake.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(21, 45);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Make";
            // 
            // gboPasswordRecovery
            // 
            this.gboPasswordRecovery.Controls.Add(this.btnRecoverPassword);
            this.gboPasswordRecovery.Controls.Add(this.txtPasswordRecoveryEmail);
            this.gboPasswordRecovery.Controls.Add(this.lblPasswordRecoveryEmail);
            this.gboPasswordRecovery.Location = new System.Drawing.Point(349, 56);
            this.gboPasswordRecovery.Name = "gboPasswordRecovery";
            this.gboPasswordRecovery.Size = new System.Drawing.Size(10, 39);
            this.gboPasswordRecovery.TabIndex = 10;
            this.gboPasswordRecovery.TabStop = false;
            this.gboPasswordRecovery.Text = "Password Recovery";
            // 
            // btnRecoverPassword
            // 
            this.btnRecoverPassword.Location = new System.Drawing.Point(224, 80);
            this.btnRecoverPassword.Name = "btnRecoverPassword";
            this.btnRecoverPassword.Size = new System.Drawing.Size(135, 23);
            this.btnRecoverPassword.TabIndex = 2;
            this.btnRecoverPassword.Text = "Recover Password";
            this.btnRecoverPassword.UseVisualStyleBackColor = true;
            this.btnRecoverPassword.Click += new System.EventHandler(this.btnRecoverPassword_Click);
            // 
            // txtPasswordRecoveryEmail
            // 
            this.txtPasswordRecoveryEmail.Location = new System.Drawing.Point(85, 54);
            this.txtPasswordRecoveryEmail.Name = "txtPasswordRecoveryEmail";
            this.txtPasswordRecoveryEmail.Size = new System.Drawing.Size(274, 20);
            this.txtPasswordRecoveryEmail.TabIndex = 1;
            // 
            // lblPasswordRecoveryEmail
            // 
            this.lblPasswordRecoveryEmail.AutoSize = true;
            this.lblPasswordRecoveryEmail.Location = new System.Drawing.Point(47, 57);
            this.lblPasswordRecoveryEmail.Name = "lblPasswordRecoveryEmail";
            this.lblPasswordRecoveryEmail.Size = new System.Drawing.Size(32, 13);
            this.lblPasswordRecoveryEmail.TabIndex = 0;
            this.lblPasswordRecoveryEmail.Text = "Email";
            // 
            // gboCompareVehicles
            // 
            this.gboCompareVehicles.Controls.Add(this.dgvCompareVehicles);
            this.gboCompareVehicles.Controls.Add(this.btnReturnToSearch);
            this.gboCompareVehicles.Location = new System.Drawing.Point(861, 304);
            this.gboCompareVehicles.Name = "gboCompareVehicles";
            this.gboCompareVehicles.Size = new System.Drawing.Size(170, 38);
            this.gboCompareVehicles.TabIndex = 11;
            this.gboCompareVehicles.TabStop = false;
            this.gboCompareVehicles.Text = "Compare Vehicles";
            // 
            // dgvCompareVehicles
            // 
            this.dgvCompareVehicles.AllowUserToAddRows = false;
            this.dgvCompareVehicles.AllowUserToDeleteRows = false;
            this.dgvCompareVehicles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvCompareVehicles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCompareVehicles.Location = new System.Drawing.Point(28, 47);
            this.dgvCompareVehicles.Name = "dgvCompareVehicles";
            this.dgvCompareVehicles.RowHeadersWidth = 62;
            this.dgvCompareVehicles.Size = new System.Drawing.Size(714, 225);
            this.dgvCompareVehicles.TabIndex = 1;
            this.dgvCompareVehicles.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnReturnToSearch
            // 
            this.btnReturnToSearch.Location = new System.Drawing.Point(28, 288);
            this.btnReturnToSearch.Name = "btnReturnToSearch";
            this.btnReturnToSearch.Size = new System.Drawing.Size(75, 23);
            this.btnReturnToSearch.TabIndex = 0;
            this.btnReturnToSearch.Text = "Return";
            this.btnReturnToSearch.UseVisualStyleBackColor = true;
            this.btnReturnToSearch.Click += new System.EventHandler(this.btnReturnToSearch_Click);
            // 
            // gboCusomterProfile
            // 
            this.gboCusomterProfile.Controls.Add(this.btnCompare);
            this.gboCusomterProfile.Controls.Add(this.btnViewTrips);
            this.gboCusomterProfile.Controls.Add(this.btnChangePassword);
            this.gboCusomterProfile.Controls.Add(this.btnViewCustomerVehicles);
            this.gboCusomterProfile.Controls.Add(this.btnAddCustomerVehicle);
            this.gboCusomterProfile.Controls.Add(this.lblWelcome);
            this.gboCusomterProfile.Location = new System.Drawing.Point(82, 56);
            this.gboCusomterProfile.Margin = new System.Windows.Forms.Padding(2);
            this.gboCusomterProfile.Name = "gboCusomterProfile";
            this.gboCusomterProfile.Padding = new System.Windows.Forms.Padding(2);
            this.gboCusomterProfile.Size = new System.Drawing.Size(766, 371);
            this.gboCusomterProfile.TabIndex = 12;
            this.gboCusomterProfile.TabStop = false;
            this.gboCusomterProfile.Text = "Customer Profile";
            // 
            // btnCompare
            // 
            this.btnCompare.Location = new System.Drawing.Point(57, 210);
            this.btnCompare.Margin = new System.Windows.Forms.Padding(2);
            this.btnCompare.Name = "btnCompare";
            this.btnCompare.Size = new System.Drawing.Size(126, 71);
            this.btnCompare.TabIndex = 5;
            this.btnCompare.Text = "Compare Vehicles";
            this.btnCompare.UseVisualStyleBackColor = true;
            this.btnCompare.Click += new System.EventHandler(this.btnCompare_Click);
            // 
            // btnViewTrips
            // 
            this.btnViewTrips.Location = new System.Drawing.Point(550, 208);
            this.btnViewTrips.Margin = new System.Windows.Forms.Padding(2);
            this.btnViewTrips.Name = "btnViewTrips";
            this.btnViewTrips.Size = new System.Drawing.Size(139, 68);
            this.btnViewTrips.TabIndex = 4;
            this.btnViewTrips.Text = "View Trips";
            this.btnViewTrips.UseVisualStyleBackColor = true;
            this.btnViewTrips.Click += new System.EventHandler(this.btnViewTrips_Click);
            // 
            // btnChangePassword
            // 
            this.btnChangePassword.Location = new System.Drawing.Point(479, 50);
            this.btnChangePassword.Margin = new System.Windows.Forms.Padding(2);
            this.btnChangePassword.Name = "btnChangePassword";
            this.btnChangePassword.Size = new System.Drawing.Size(135, 58);
            this.btnChangePassword.TabIndex = 3;
            this.btnChangePassword.Text = "Change Password";
            this.btnChangePassword.UseVisualStyleBackColor = true;
            this.btnChangePassword.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnViewCustomerVehicles
            // 
            this.btnViewCustomerVehicles.Location = new System.Drawing.Point(380, 208);
            this.btnViewCustomerVehicles.Margin = new System.Windows.Forms.Padding(2);
            this.btnViewCustomerVehicles.Name = "btnViewCustomerVehicles";
            this.btnViewCustomerVehicles.Size = new System.Drawing.Size(139, 68);
            this.btnViewCustomerVehicles.TabIndex = 2;
            this.btnViewCustomerVehicles.Text = "Track Fuel Consumption";
            this.btnViewCustomerVehicles.UseVisualStyleBackColor = true;
            this.btnViewCustomerVehicles.Click += new System.EventHandler(this.btnViewCustomerVehicles_Click);
            // 
            // btnAddCustomerVehicle
            // 
            this.btnAddCustomerVehicle.Location = new System.Drawing.Point(220, 208);
            this.btnAddCustomerVehicle.Margin = new System.Windows.Forms.Padding(2);
            this.btnAddCustomerVehicle.Name = "btnAddCustomerVehicle";
            this.btnAddCustomerVehicle.Size = new System.Drawing.Size(126, 71);
            this.btnAddCustomerVehicle.TabIndex = 1;
            this.btnAddCustomerVehicle.Text = "Add Vehicle to Account";
            this.btnAddCustomerVehicle.UseVisualStyleBackColor = true;
            this.btnAddCustomerVehicle.Click += new System.EventHandler(this.btnAddCustomerVehicle_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(39, 46);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(55, 13);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome!";
            // 
            // gboChangePassword
            // 
            this.gboChangePassword.Controls.Add(this.btnChangeUserPassword);
            this.gboChangePassword.Controls.Add(this.txtConfirmNewPassword);
            this.gboChangePassword.Controls.Add(this.txtNewPassword);
            this.gboChangePassword.Controls.Add(this.txtCurrentPassword);
            this.gboChangePassword.Controls.Add(this.lblConfirmPassword);
            this.gboChangePassword.Controls.Add(this.lblNewPassword);
            this.gboChangePassword.Controls.Add(this.lblCurrentPassword);
            this.gboChangePassword.Location = new System.Drawing.Point(837, 237);
            this.gboChangePassword.Margin = new System.Windows.Forms.Padding(2);
            this.gboChangePassword.Name = "gboChangePassword";
            this.gboChangePassword.Padding = new System.Windows.Forms.Padding(2);
            this.gboChangePassword.Size = new System.Drawing.Size(81, 37);
            this.gboChangePassword.TabIndex = 13;
            this.gboChangePassword.TabStop = false;
            this.gboChangePassword.Text = "Change Password";
            // 
            // btnChangeUserPassword
            // 
            this.btnChangeUserPassword.Location = new System.Drawing.Point(303, 179);
            this.btnChangeUserPassword.Margin = new System.Windows.Forms.Padding(2);
            this.btnChangeUserPassword.Name = "btnChangeUserPassword";
            this.btnChangeUserPassword.Size = new System.Drawing.Size(89, 42);
            this.btnChangeUserPassword.TabIndex = 6;
            this.btnChangeUserPassword.Text = "Change Password";
            this.btnChangeUserPassword.UseVisualStyleBackColor = true;
            this.btnChangeUserPassword.Click += new System.EventHandler(this.btnChangeUserPassword_Click);
            // 
            // txtConfirmNewPassword
            // 
            this.txtConfirmNewPassword.Location = new System.Drawing.Point(186, 148);
            this.txtConfirmNewPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txtConfirmNewPassword.Name = "txtConfirmNewPassword";
            this.txtConfirmNewPassword.PasswordChar = '*';
            this.txtConfirmNewPassword.Size = new System.Drawing.Size(208, 20);
            this.txtConfirmNewPassword.TabIndex = 5;
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.Location = new System.Drawing.Point(186, 110);
            this.txtNewPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.PasswordChar = '*';
            this.txtNewPassword.Size = new System.Drawing.Size(208, 20);
            this.txtNewPassword.TabIndex = 4;
            // 
            // txtCurrentPassword
            // 
            this.txtCurrentPassword.Location = new System.Drawing.Point(186, 73);
            this.txtCurrentPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txtCurrentPassword.Name = "txtCurrentPassword";
            this.txtCurrentPassword.PasswordChar = '*';
            this.txtCurrentPassword.Size = new System.Drawing.Size(208, 20);
            this.txtCurrentPassword.TabIndex = 3;
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.AutoSize = true;
            this.lblConfirmPassword.Location = new System.Drawing.Point(51, 148);
            this.lblConfirmPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(116, 13);
            this.lblConfirmPassword.TabIndex = 2;
            this.lblConfirmPassword.Text = "Confirm New Password";
            // 
            // lblNewPassword
            // 
            this.lblNewPassword.AutoSize = true;
            this.lblNewPassword.Location = new System.Drawing.Point(51, 114);
            this.lblNewPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNewPassword.Name = "lblNewPassword";
            this.lblNewPassword.Size = new System.Drawing.Size(78, 13);
            this.lblNewPassword.TabIndex = 1;
            this.lblNewPassword.Text = "New Password";
            // 
            // lblCurrentPassword
            // 
            this.lblCurrentPassword.AutoSize = true;
            this.lblCurrentPassword.Location = new System.Drawing.Point(51, 77);
            this.lblCurrentPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCurrentPassword.Name = "lblCurrentPassword";
            this.lblCurrentPassword.Size = new System.Drawing.Size(90, 13);
            this.lblCurrentPassword.TabIndex = 0;
            this.lblCurrentPassword.Text = "Current Password";
            // 
            // gboAddVehicleSearch
            // 
            this.gboAddVehicleSearch.Controls.Add(this.btnAddVehicleSearch);
            this.gboAddVehicleSearch.Controls.Add(this.label16);
            this.gboAddVehicleSearch.Controls.Add(this.cboAddVehicleSearchYear);
            this.gboAddVehicleSearch.Controls.Add(this.label17);
            this.gboAddVehicleSearch.Controls.Add(this.cboAddVehicleSearchModel);
            this.gboAddVehicleSearch.Controls.Add(this.label18);
            this.gboAddVehicleSearch.Controls.Add(this.cboAddVehicleSearchMake);
            this.gboAddVehicleSearch.Controls.Add(this.dgvAddVehicleSearch);
            this.gboAddVehicleSearch.Location = new System.Drawing.Point(580, 45);
            this.gboAddVehicleSearch.Name = "gboAddVehicleSearch";
            this.gboAddVehicleSearch.Size = new System.Drawing.Size(192, 31);
            this.gboAddVehicleSearch.TabIndex = 11;
            this.gboAddVehicleSearch.TabStop = false;
            this.gboAddVehicleSearch.Text = "Add Vehicle Search";
            // 
            // btnAddVehicleSearch
            // 
            this.btnAddVehicleSearch.Location = new System.Drawing.Point(366, 388);
            this.btnAddVehicleSearch.Name = "btnAddVehicleSearch";
            this.btnAddVehicleSearch.Size = new System.Drawing.Size(105, 52);
            this.btnAddVehicleSearch.TabIndex = 7;
            this.btnAddVehicleSearch.Text = "Add Vehicle";
            this.btnAddVehicleSearch.UseVisualStyleBackColor = true;
            this.btnAddVehicleSearch.Click += new System.EventHandler(this.btnAddVehicleSearch_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(538, 71);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 13);
            this.label16.TabIndex = 6;
            this.label16.Text = "Year";
            // 
            // cboAddVehicleSearchYear
            // 
            this.cboAddVehicleSearchYear.FormattingEnabled = true;
            this.cboAddVehicleSearchYear.Location = new System.Drawing.Point(607, 68);
            this.cboAddVehicleSearchYear.Name = "cboAddVehicleSearchYear";
            this.cboAddVehicleSearchYear.Size = new System.Drawing.Size(121, 21);
            this.cboAddVehicleSearchYear.TabIndex = 5;
            this.cboAddVehicleSearchYear.SelectedIndexChanged += new System.EventHandler(this.cboAddVehicleSearchYear_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(297, 68);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 13);
            this.label17.TabIndex = 4;
            this.label17.Text = "Model";
            // 
            // cboAddVehicleSearchModel
            // 
            this.cboAddVehicleSearchModel.FormattingEnabled = true;
            this.cboAddVehicleSearchModel.Location = new System.Drawing.Point(366, 65);
            this.cboAddVehicleSearchModel.Name = "cboAddVehicleSearchModel";
            this.cboAddVehicleSearchModel.Size = new System.Drawing.Size(121, 21);
            this.cboAddVehicleSearchModel.TabIndex = 3;
            this.cboAddVehicleSearchModel.SelectedIndexChanged += new System.EventHandler(this.cboAddVehicleSearchModel_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(67, 68);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(34, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "Make";
            // 
            // cboAddVehicleSearchMake
            // 
            this.cboAddVehicleSearchMake.FormattingEnabled = true;
            this.cboAddVehicleSearchMake.Location = new System.Drawing.Point(136, 65);
            this.cboAddVehicleSearchMake.Name = "cboAddVehicleSearchMake";
            this.cboAddVehicleSearchMake.Size = new System.Drawing.Size(121, 21);
            this.cboAddVehicleSearchMake.TabIndex = 1;
            this.cboAddVehicleSearchMake.SelectedIndexChanged += new System.EventHandler(this.cboAddVehicleSearchMake_SelectedIndexChanged);
            // 
            // dgvAddVehicleSearch
            // 
            this.dgvAddVehicleSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAddVehicleSearch.Location = new System.Drawing.Point(136, 135);
            this.dgvAddVehicleSearch.Name = "dgvAddVehicleSearch";
            this.dgvAddVehicleSearch.RowHeadersWidth = 62;
            this.dgvAddVehicleSearch.Size = new System.Drawing.Size(571, 247);
            this.dgvAddVehicleSearch.TabIndex = 0;
            // 
            // gboFuelTracking
            // 
            this.gboFuelTracking.Controls.Add(this.txtFuelTrackGallonsFilled);
            this.gboFuelTracking.Controls.Add(this.label19);
            this.gboFuelTracking.Controls.Add(this.cboxFirstTrip);
            this.gboFuelTracking.Controls.Add(this.dgvFuelTracking);
            this.gboFuelTracking.Controls.Add(this.label24);
            this.gboFuelTracking.Controls.Add(this.btnFuelTracking);
            this.gboFuelTracking.Controls.Add(this.txtFuelTrackingPercent);
            this.gboFuelTracking.Controls.Add(this.label22);
            this.gboFuelTracking.Controls.Add(this.txtFuelTrackingOdometer);
            this.gboFuelTracking.Controls.Add(this.label23);
            this.gboFuelTracking.Location = new System.Drawing.Point(242, 63);
            this.gboFuelTracking.Name = "gboFuelTracking";
            this.gboFuelTracking.Size = new System.Drawing.Size(101, 52);
            this.gboFuelTracking.TabIndex = 11;
            this.gboFuelTracking.TabStop = false;
            this.gboFuelTracking.Text = "Fuel Tracking";
            // 
            // txtFuelTrackGallonsFilled
            // 
            this.txtFuelTrackGallonsFilled.Location = new System.Drawing.Point(512, 333);
            this.txtFuelTrackGallonsFilled.Name = "txtFuelTrackGallonsFilled";
            this.txtFuelTrackGallonsFilled.Size = new System.Drawing.Size(62, 20);
            this.txtFuelTrackGallonsFilled.TabIndex = 15;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(437, 338);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(69, 13);
            this.label19.TabIndex = 14;
            this.label19.Text = "Gallons Filled";
            // 
            // cboxFirstTrip
            // 
            this.cboxFirstTrip.AutoSize = true;
            this.cboxFirstTrip.Location = new System.Drawing.Point(600, 336);
            this.cboxFirstTrip.Name = "cboxFirstTrip";
            this.cboxFirstTrip.Size = new System.Drawing.Size(112, 17);
            this.cboxFirstTrip.TabIndex = 13;
            this.cboxFirstTrip.Text = "Is this your first trip";
            this.cboxFirstTrip.UseVisualStyleBackColor = true;
            // 
            // dgvFuelTracking
            // 
            this.dgvFuelTracking.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFuelTracking.Location = new System.Drawing.Point(24, 43);
            this.dgvFuelTracking.Name = "dgvFuelTracking";
            this.dgvFuelTracking.Size = new System.Drawing.Size(725, 282);
            this.dgvFuelTracking.TabIndex = 12;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(405, 338);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(15, 13);
            this.label24.TabIndex = 11;
            this.label24.Text = "%";
            // 
            // btnFuelTracking
            // 
            this.btnFuelTracking.Location = new System.Drawing.Point(241, 395);
            this.btnFuelTracking.Name = "btnFuelTracking";
            this.btnFuelTracking.Size = new System.Drawing.Size(254, 40);
            this.btnFuelTracking.TabIndex = 10;
            this.btnFuelTracking.Text = "Track Fuel";
            this.btnFuelTracking.UseVisualStyleBackColor = true;
            this.btnFuelTracking.Click += new System.EventHandler(this.btnFuelTracking_Click);
            // 
            // txtFuelTrackingPercent
            // 
            this.txtFuelTrackingPercent.Location = new System.Drawing.Point(367, 335);
            this.txtFuelTrackingPercent.Name = "txtFuelTrackingPercent";
            this.txtFuelTrackingPercent.Size = new System.Drawing.Size(32, 20);
            this.txtFuelTrackingPercent.TabIndex = 3;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(302, 337);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(59, 13);
            this.label22.TabIndex = 2;
            this.label22.Text = "Fill Percent";
            // 
            // txtFuelTrackingOdometer
            // 
            this.txtFuelTrackingOdometer.Location = new System.Drawing.Point(209, 335);
            this.txtFuelTrackingOdometer.Name = "txtFuelTrackingOdometer";
            this.txtFuelTrackingOdometer.Size = new System.Drawing.Size(86, 20);
            this.txtFuelTrackingOdometer.TabIndex = 1;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(113, 338);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(78, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "New Odometer";
            // 
            // gboCustomerTrips
            // 
            this.gboCustomerTrips.Controls.Add(this.graphCustomerTrip);
            this.gboCustomerTrips.Controls.Add(this.listBoxCustomerVehicles);
            this.gboCustomerTrips.Controls.Add(this.dgvCustomerTrips);
            this.gboCustomerTrips.Location = new System.Drawing.Point(654, 433);
            this.gboCustomerTrips.Name = "gboCustomerTrips";
            this.gboCustomerTrips.Size = new System.Drawing.Size(261, 71);
            this.gboCustomerTrips.TabIndex = 14;
            this.gboCustomerTrips.TabStop = false;
            this.gboCustomerTrips.Text = "Trips";
            // 
            // graphCustomerTrip
            // 
            this.graphCustomerTrip.BackColor = System.Drawing.Color.WhiteSmoke;
            chartArea3.Name = "ChartArea1";
            this.graphCustomerTrip.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.graphCustomerTrip.Legends.Add(legend3);
            this.graphCustomerTrip.Location = new System.Drawing.Point(21, 317);
            this.graphCustomerTrip.Name = "graphCustomerTrip";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "MPG";
            series3.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            this.graphCustomerTrip.Series.Add(series3);
            this.graphCustomerTrip.Size = new System.Drawing.Size(781, 173);
            this.graphCustomerTrip.TabIndex = 2;
            this.graphCustomerTrip.Text = "Fuel Track";
            this.graphCustomerTrip.Click += new System.EventHandler(this.graphCustomerTrip_Click);
            // 
            // listBoxCustomerVehicles
            // 
            this.listBoxCustomerVehicles.FormattingEnabled = true;
            this.listBoxCustomerVehicles.Location = new System.Drawing.Point(619, 81);
            this.listBoxCustomerVehicles.Name = "listBoxCustomerVehicles";
            this.listBoxCustomerVehicles.Size = new System.Drawing.Size(183, 212);
            this.listBoxCustomerVehicles.TabIndex = 1;
            this.listBoxCustomerVehicles.SelectedIndexChanged += new System.EventHandler(this.listBoxCustomerVehicles_SelectedIndexChanged);
            // 
            // dgvCustomerTrips
            // 
            this.dgvCustomerTrips.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomerTrips.Location = new System.Drawing.Point(21, 81);
            this.dgvCustomerTrips.Name = "dgvCustomerTrips";
            this.dgvCustomerTrips.Size = new System.Drawing.Size(592, 209);
            this.dgvCustomerTrips.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(944, 561);
            this.Controls.Add(this.gboSearch);
            this.Controls.Add(this.gboCustomerTrips);
            this.Controls.Add(this.gboFuelTracking);
            this.Controls.Add(this.gboAddVehicleSearch);
            this.Controls.Add(this.gboChangePassword);
            this.Controls.Add(this.gboCusomterProfile);
            this.Controls.Add(this.gboCompareVehicles);
            this.Controls.Add(this.gboPasswordRecovery);
            this.Controls.Add(this.gboAddVehicle);
            this.Controls.Add(this.gboCreateAccount);
            this.Controls.Add(this.gboLogin);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Fuel Economy Researcher & Tracker";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gboLogin.ResumeLayout(false);
            this.gboLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbFrontPage)).EndInit();
            this.gboSearch.ResumeLayout(false);
            this.gboSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearch)).EndInit();
            this.gboCreateAccount.ResumeLayout(false);
            this.gboCreateAccount.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.gboAddVehicle.ResumeLayout(false);
            this.gboAddVehicle.PerformLayout();
            this.gboPasswordRecovery.ResumeLayout(false);
            this.gboPasswordRecovery.PerformLayout();
            this.gboCompareVehicles.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCompareVehicles)).EndInit();
            this.gboCusomterProfile.ResumeLayout(false);
            this.gboCusomterProfile.PerformLayout();
            this.gboChangePassword.ResumeLayout(false);
            this.gboChangePassword.PerformLayout();
            this.gboAddVehicleSearch.ResumeLayout(false);
            this.gboAddVehicleSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAddVehicleSearch)).EndInit();
            this.gboFuelTracking.ResumeLayout(false);
            this.gboFuelTracking.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFuelTracking)).EndInit();
            this.gboCustomerTrips.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.graphCustomerTrip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerTrips)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gboLogin;
        private System.Windows.Forms.Button btnCreateAccount;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.TextBox txtUserPass;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUserEmail;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gboCreateAccount;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtCreatePassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCreateEmail;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.TextBox txtCreateLastName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCreateFirstName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox gboSearch;
        private System.Windows.Forms.DataGridView dgvSearch;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cboYear;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cboModel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cboMake;
        private System.Windows.Forms.Button btnAddVehicle;
        private System.Windows.Forms.GroupBox gboAddVehicle;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtAddMaxGallons;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAddOdo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtAddYear;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtAddModel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtAddMake;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Button btnPasswordRecovery;
        private System.Windows.Forms.GroupBox gboPasswordRecovery;
        private System.Windows.Forms.Button btnRecoverPassword;
        private System.Windows.Forms.TextBox txtPasswordRecoveryEmail;
        private System.Windows.Forms.Label lblPasswordRecoveryEmail;
        private System.Windows.Forms.ToolStripMenuItem profileToolStripMenuItem;
        private System.Windows.Forms.ListBox listBoxCompareCart;
        private System.Windows.Forms.Button btnCompareVehicles;
        private System.Windows.Forms.Button btnRemoveItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.GroupBox gboCompareVehicles;
        private System.Windows.Forms.DataGridView dgvCompareVehicles;
        private System.Windows.Forms.Button btnReturnToSearch;
        private System.Windows.Forms.GroupBox gboCusomterProfile;
        private System.Windows.Forms.Button btnChangePassword;
        private System.Windows.Forms.Button btnViewCustomerVehicles;
        private System.Windows.Forms.Button btnAddCustomerVehicle;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.GroupBox gboChangePassword;
        private System.Windows.Forms.Button btnChangeUserPassword;
        private System.Windows.Forms.TextBox txtConfirmNewPassword;
        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.TextBox txtCurrentPassword;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.Label lblNewPassword;
        private System.Windows.Forms.Label lblCurrentPassword;
        private System.Windows.Forms.GroupBox gboAddVehicleSearch;
        private System.Windows.Forms.Button btnAddVehicleSearch;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cboAddVehicleSearchYear;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cboAddVehicleSearchModel;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cboAddVehicleSearchMake;
        private System.Windows.Forms.DataGridView dgvAddVehicleSearch;
        private System.Windows.Forms.GroupBox gboFuelTracking;
        private System.Windows.Forms.DataGridView dgvFuelTracking;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btnFuelTracking;
        private System.Windows.Forms.TextBox txtFuelTrackingPercent;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtFuelTrackingOdometer;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.CheckBox cboxFirstTrip;
        private System.Windows.Forms.TextBox txtFuelTrackGallonsFilled;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnViewTrips;
        private System.Windows.Forms.GroupBox gboCustomerTrips;
        private System.Windows.Forms.ListBox listBoxCustomerVehicles;
        private System.Windows.Forms.DataGridView dgvCustomerTrips;
        private System.Windows.Forms.DataVisualization.Charting.Chart graphCustomerTrip;
        private System.Windows.Forms.PictureBox picbFrontPage;
        private System.Windows.Forms.PictureBox picbSearch;
        private System.Windows.Forms.Button btnCompare;
    }
}

